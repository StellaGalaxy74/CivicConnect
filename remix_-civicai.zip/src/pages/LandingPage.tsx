import { useApp } from '../App';
import { useNavigate, Link } from 'react-router-dom';
import { User, ShieldCheck, ArrowRight, Building2, Zap, BarChart3, Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function LandingPage() {
  const { user } = useApp();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-surface selection:bg-primary/20">
      {/* Header/Nav */}
      <nav className="h-20 px-6 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
            <Building2 className="w-6 h-6" />
          </div>
          <span className="text-xl font-black tracking-tight text-primary">CivicAI</span>
        </div>
        <div className="flex items-center gap-4">
          {user ? (
            <Link to={user.role === 'admin' ? "/admin/dashboard" : "/dashboard"} className="h-11 px-6 bg-primary text-white rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-primary/10 hover:brightness-110 transition-all">
              Dashboard
              <ArrowRight className="w-4 h-4" />
            </Link>
          ) : (
            <>
              <Link to="/login" className="text-sm font-bold text-on-surface-variant hover:text-primary transition-colors">Sign In</Link>
              <Link to="/signup" className="h-11 px-6 bg-primary text-white rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-primary/10 hover:brightness-110 transition-all">
                Get Started
                <ArrowRight className="w-4 h-4" />
              </Link>
            </>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-6 pt-12 pb-24">
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary/5 border border-primary/10 rounded-full text-primary text-[10px] font-black uppercase tracking-widest mb-6"
          >
            <Zap className="w-3 h-3 fill-current" />
            Revolutionizing Municipal Management
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-black tracking-tight mb-6 font-display max-w-4xl mx-auto leading-[1.1]"
          >
            Bridge the gap between <span className="text-primary italic">Citizens</span> and <span className="text-primary">Authorities</span>.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-on-surface-variant max-w-2xl mx-auto mb-10 font-medium"
          >
            A high-performance platform for real-time community improvements, smart triage, and transparent urban development.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap justify-center gap-4"
          >
            <Link to="/signup" className="h-14 px-8 bg-primary text-white rounded-2xl text-base font-bold flex items-center gap-3 shadow-xl hover:translate-y-[-2px] transition-all">
              Join the Community
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link to="/login" className="h-14 px-8 bg-white border border-outline-variant/30 rounded-2xl text-base font-bold flex items-center gap-3 shadow-sm hover:bg-surface transition-all">
              Administrative Login
            </Link>
          </motion.div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-24">
           {[
             { title: 'Real-time Reporting', desc: 'Capture and submit issues in seconds with precise geo-location and image support.', icon: Globe, color: 'text-blue-500' },
             { title: 'Smart Triage', desc: 'AI-driven classification ensures reports reach the right municipal department instantly.', icon: Zap, color: 'text-amber-500' },
             { title: 'Data Analytics', desc: 'Visualize hotspots and resolution trends to make informed city planning decisions.', icon: BarChart3, color: 'text-emerald-500' }
           ].map((feature, idx) => (
             <motion.div 
               key={feature.title}
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.4 + idx * 0.1 }}
               className="p-8 bg-white border border-outline-variant/30 rounded-3xl hover:shadow-xl hover:shadow-primary/5 transition-all"
             >
               <feature.icon className={cn("w-10 h-10 mb-6", feature.color)} />
               <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
               <p className="text-on-surface-variant text-sm leading-relaxed">{feature.desc}</p>
             </motion.div>
           ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Citizen Card */}
          <div className="group relative bg-[#0F172A] text-white rounded-[40px] p-8 md:p-12 overflow-hidden">
             <div className="relative z-10">
                <div className="mb-6 p-4 bg-white/10 rounded-2xl inline-flex">
                   <User className="w-8 h-8" />
                </div>
                <h2 className="text-3xl font-bold mb-4">For Citizens</h2>
                <p className="text-white/70 mb-8 max-w-sm">
                  Empower your voice. Report infrastructure issues, track progress, and see the impact of your contributions.
                </p>
                <Link to="/signup" className="inline-flex items-center gap-2 font-black text-xs uppercase tracking-widest hover:gap-4 transition-all">
                   Register to Report <ArrowRight className="w-4 h-4" />
                </Link>
             </div>
             <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/4"></div>
          </div>

          {/* Admin Card */}
          <div className="group relative bg-primary text-white rounded-[40px] p-8 md:p-12 overflow-hidden">
             <div className="relative z-10">
                <div className="mb-6 p-4 bg-white/10 rounded-2xl inline-flex">
                   <ShieldCheck className="w-8 h-8" />
                </div>
                <h2 className="text-3xl font-bold mb-4">For Authorities</h2>
                <p className="text-white/80 mb-8 max-w-sm">
                   A comprehensive workspace for municipal staff to manage, assign, and resolve community escalations.
                </p>
                <Link to="/login" className="inline-flex items-center gap-2 font-black text-xs uppercase tracking-widest hover:gap-4 transition-all">
                   Admin Dashboard <ArrowRight className="w-4 h-4" />
                </Link>
             </div>
             <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-[80px] translate-y-1/2 -translate-x-1/4"></div>
          </div>
        </div>
      </main>

      <footer className="border-t border-outline-variant/30 py-12 px-6">
         <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2 opacity-50">
               <Building2 className="w-5 h-5" />
               <span className="font-bold">CivicAI &copy; 2026</span>
            </div>
            <div className="flex gap-8 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">
               <a href="#" className="hover:text-primary">Privacy Policy</a>
               <a href="#" className="hover:text-primary">Terms of Service</a>
               <a href="#" className="hover:text-primary">Help Center</a>
            </div>
         </div>
      </footer>
    </div>
  );
}
