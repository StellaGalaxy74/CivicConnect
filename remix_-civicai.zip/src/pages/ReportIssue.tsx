import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Trash2, 
  Map as MapIcon, 
  Droplets, 
  Zap, 
  MoreHorizontal, 
  Mic, 
  Camera, 
  Navigation, 
  Send, 
  ArrowLeft 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useApp } from '../App';
import { issueService } from '../services/issueService';
import DateTimePicker from '../components/DateTimePicker';
import VoiceInput from '../components/VoiceInput';
import CameraCapture from '../components/CameraCapture';

const CATEGORIES = [
  { id: 'sanitation', name: 'Sanitation', icon: Trash2 },
  { id: 'roads', name: 'Roads', icon: MapIcon },
  { id: 'water', name: 'Water', icon: Droplets },
  { id: 'electricity', name: 'Electricity', icon: Zap },
  { id: 'other', name: 'Other', icon: MoreHorizontal },
];

export default function ReportIssuePage() {
  const { user } = useApp();
  const [category, setCategory] = useState('sanitation');
  const [summary, setSummary] = useState('');
  const [occurrenceDate, setOccurrenceDate] = useState(new Date().toISOString().split('T')[0]);
  const [occurrenceTime, setOccurrenceTime] = useState(new Date().toTimeString().split(' ')[0].substring(0, 5));
  const [images, setImages] = useState<string[]>([]);
  const [locationText, setLocationText] = useState('123 Civic Plaza, Downtown Metropolitan');
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser');
      return;
    }

    setError(null);
    setDetecting(true);
    navigator.geolocation.getCurrentPosition(async (position) => {
      const { latitude, longitude } = position.coords;
      setCoords({ lat: latitude, lng: longitude });
      
      // Attempt reverse geocoding
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
        const data = await response.json();
        if (data.display_name) {
          setLocationText(data.display_name);
        }
      } catch (error) {
        console.error('Reverse geocoding failed:', error);
        setLocationText(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
      } finally {
        setDetecting(false);
      }
    }, (error) => {
      console.error('Error detecting location:', error);
      setDetecting(false);
      setError('Could not detect your location. Please check your permissions.');
    });
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('You must be signed in to report an issue.');
      return;
    }
    
    setLoading(true);
    setError(null);
    try {
      await issueService.createIssue({
        title: `${category.charAt(0).toUpperCase() + category.slice(1)} Issue`,
        summary,
        category: category as any,
        location: locationText,
        latitude: coords?.lat || null,
        longitude: coords?.lng || null,
        occurrenceDate,
        occurrenceTime,
        images,
        authorId: user.id,
        authorName: user.name,
      });
      navigate('/dashboard');
    } catch (err: any) {
      console.error('Failed to submit report:', err);
      // Try to parse JSON error if it's from our handler
      try {
        const parsed = JSON.parse(err.message);
        setError(`Submission failed: ${parsed.error}`);
      } catch {
        setError(err.message || 'An unexpected error occurred during submission.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVoiceTranscript = (transcript: string) => {
    setSummary((prev) => (prev ? `${prev} ${transcript}` : transcript));
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 md:py-12">
      <header className="mb-10 flex items-start gap-4">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-surface-container rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight mb-2">Report an Issue</h1>
          <p className="text-on-surface-variant font-medium">Your report helps us build a more efficient and responsive city. Please provide as much detail as possible.</p>
          {error && (
            <div className="mt-4 p-4 bg-error/10 border border-error/20 rounded-xl text-error text-sm font-bold flex items-center gap-3">
              <span className="flex-1">{error}</span>
              <button 
                type="button"
                onClick={() => setError(null)} 
                className="text-xs uppercase tracking-widest hover:underline"
              >
                Dismiss
              </button>
            </div>
          )}
        </div>
      </header>

      <form className="space-y-6" onSubmit={handleReportSubmit}>
        {/* Category */}
        <section className="bg-white border border-outline-variant/50 rounded-2xl p-6 shadow-sm">
          <h3 className="text-lg font-bold mb-4">Category</h3>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id)}
                className={cn(
                  "px-4 py-2.5 rounded-full border flex items-center gap-2 transition-all font-bold text-sm",
                  category === cat.id 
                    ? "bg-secondary border-secondary text-white shadow-md shadow-secondary/20" 
                    : "border-outline-variant text-on-surface-variant hover:border-on-surface/30 hover:text-on-surface"
                )}
              >
                <cat.icon className="w-4 h-4" />
                {cat.name}
              </button>
            ))}
          </div>
        </section>

        {/* Summary */}
        <section className="bg-white border border-outline-variant/30 rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <label htmlFor="summary" className="text-lg font-bold">Issue Summary</label>
            <VoiceInput onTranscript={handleVoiceTranscript} />
          </div>
          <textarea 
            id="summary"
            rows={4}
            required
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            className="w-full bg-surface-bright border border-outline-variant/50 rounded-xl p-4 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all placeholder:text-outline font-medium text-sm lg:text-base"
            placeholder="Describe the issue you've encountered..."
          />
          <p className="text-xs text-on-surface-variant mt-4 font-medium opacity-70 italic">Example: 'Broken street light at the corner of 5th and Main.'</p>
        </section>

        {/* Date & Time */}
        <DateTimePicker 
          date={occurrenceDate} 
          time={occurrenceTime}
          onDateChange={setOccurrenceDate}
          onTimeChange={setOccurrenceTime}
        />

        {/* Uploads */}
        <CameraCapture images={images} onImagesChange={setImages} />

        {/* Location */}
        <section className="bg-white border border-outline-variant/30 rounded-2xl p-6 shadow-sm overflow-hidden">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold">Location</h3>
            <button 
              type="button" 
              onClick={handleDetectLocation}
              disabled={detecting}
              className={cn(
                "flex items-center gap-2 text-secondary font-bold text-xs hover:underline disabled:opacity-50 transition-all",
                detecting && "animate-pulse"
              )}
            >
              <Navigation className={cn("w-4 h-4 fill-current", detecting && "animate-spin")} />
              {detecting ? 'Detecting...' : 'Detect My Location'}
            </button>
          </div>
          <div className="h-56 w-full rounded-xl bg-surface-container-high overflow-hidden relative border border-outline-variant/30">
            <img 
              src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&q=80&w=2000" 
              alt="Map location picker" 
              className="w-full h-full object-cover grayscale opacity-50" 
            />
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="relative">
                <MapIcon className="w-10 h-10 text-error fill-current drop-shadow-lg animate-bounce" />
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-surface/80 to-transparent pointer-events-none" />
          </div>
          <div className="mt-4 p-4 bg-surface-container-low rounded-xl border border-outline-variant/30 flex items-center gap-3">
             <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-on-surface-variant flex-shrink-0">
              <MapIcon className="w-5 h-5" />
             </div>
            <input 
              type="text"
              value={locationText}
              onChange={(e) => setLocationText(e.target.value)}
              className="bg-transparent border-none outline-none text-sm font-bold text-on-surface flex-1"
            />
          </div>
        </section>

        {/* Submit */}
        <div className="pt-4 pb-12">
          <button 
            type="submit"
            disabled={loading}
            className="w-full h-14 bg-primary text-white font-bold text-lg rounded-2xl hover:opacity-90 active:scale-[0.99] transition-all flex items-center justify-center gap-3 shadow-xl shadow-primary/10 disabled:opacity-50"
          >
            {loading ? 'Submitting...' : 'Submit Report'}
            <Send className="w-5 h-5" />
          </button>
          <p className="text-center text-xs text-on-surface-variant font-bold mt-6 opacity-60 uppercase tracking-widest">
            By submitting, you agree to our Terms of Service regarding data usage.
          </p>
        </div>
      </form>
    </div>
  );
}

