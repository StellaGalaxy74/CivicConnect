# Security Specification - CivicAI

## Data Invariants
1. A user can only edit their own profile (except for role management which is admin-only).
2. Any citizen can create an issue.
3. Only the author of an issue or an admin can update an issue's details.
4. Only admins can update the `status` of an issue (to 'assigned', 'resolved', etc).
5. Admins have full read/write access to all collections.
6. Issues are public (everyone can read them).

## The Dirty Dozen (Attack Vectors)
1. **Identity Theft**: User A tries to update User B's profile.
2. **Privilege Escalation**: Citizen tries to set their own role to 'admin'.
3. **Shadow Field Injection**: User tries to inject `isVerified: true` into their profile.
4. **Orphaned Issue**: User tries to create an issue with a fake `authorId`.
5. **Unauthorized Status Shift**: Citizen tries to mark their own issue as 'resolved' without admin approval.
6. **ID Poisoning**: User tries to create a document with a 2MB string as ID.
7. **Resource Exhaustion**: User tries to send a 1MB string for the `title` field.
8. **PII Leak**: Unauthorized user tries to list all user emails.
9. **Timestamp Spoofing**: User tries to set a backdated `createdAt`.
10. **Malicious Category**: User tries to set `category` to `malware`.
11. **Delete Protection**: Citizen tries to delete an issue reported by another user.
12. **Bulk Scraper**: User tries to list all users without being an admin.

## Test Runner (Logic Verification)
The following tests will be implemented in `firestore.rules.test.ts` (conceptual for now as I will write the rules directly based on these).
- `FAIL`: create user with `role: 'admin'` as citizen.
- `FAIL`: update another user's `name`.
- `FAIL`: create issue with `authorId` mismatching `auth.uid`.
- `PASS`: public can read issues.
- `PASS`: citizen can create an issue.
- `PASS`: admin can update issue status.
- `FAIL`: citizen can update issue status.
