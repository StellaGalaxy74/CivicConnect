import { BrowserRouter as Router, Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import { useState, createContext, useContext, useEffect } from 'react';
import { Navbar, BottomNav, AdminSidebar } from './components/Navigation';
import { Role, User } from './types';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import CitizenDashboard from './pages/CitizenDashboard';
import ReportIssuePage from './pages/ReportIssue';
import ProfilePage from './pages/ProfilePage';
import AdminDashboard from './pages/AdminDashboard';
import AdminProfilePage from './pages/AdminProfile';
import ComplaintDetailPage from './pages/ComplaintDetail';
import DuplicateDetectionPage from './pages/DuplicateDetection';
import HotspotMapPage from './pages/HotspotMap';
import { auth } from './lib/firebase';
import { onAuthStateChanged, signOut as firebaseSignOut } from 'firebase/auth';
import { userService } from './services/userService';

interface AppContextType {
  role: Role;
  user: User | null;
  loading: boolean;
  setRole: (role: Role) => void;
  setUser: (user: User | null) => void;
  signOut: () => Promise<void>;
  switchRole: (newRole: Role) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};

export default function App() {
  const [role, setRole] = useState<Role>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        const profile = await userService.getUserProfile(firebaseUser.uid);
        if (profile) {
          setUser(profile);
          setRole(profile.role);
        } else {
          // If profile doesn't exist, we might need to create one (handled in Login/Signup)
          // For now, just set user state so UI can let them finish setup if needed
          setUser({
            id: firebaseUser.uid,
            email: firebaseUser.email || '',
            name: firebaseUser.displayName || 'Anonymous',
            role: 'citizen'
          });
          setRole('citizen');
        }
      } else {
        setUser(null);
        setRole(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await firebaseSignOut(auth);
    setRole(null);
    setUser(null);
  };

  const switchRole = (newRole: Role) => {
    if (user?.role === 'admin') {
      setRole(newRole);
      // We need to use a hook for navigation, but App is the top level.
      // We can handle this in the switchRole call sites or wrap the Provider content.
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <AppContext.Provider value={{ role, user, loading, setRole, setUser, signOut: handleSignOut, switchRole }}>
      <Router>
        <div className="min-h-screen flex flex-col">
          {role && <Navbar role={role} user={user} />}
          <main className={role === 'admin' ? "md:ml-64 pt-16 flex-1 bg-surface" : (role === 'citizen' ? "pt-16 pb-24 md:pb-0 flex-1 bg-surface" : "flex-1 bg-surface")}>
            {role === 'admin' && <AdminSidebar />}
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signin" element={<Navigate to="/login" replace />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />
              
              {/* Protected Citizen Routes */}
              <Route path="/dashboard" element={role === 'citizen' ? <CitizenDashboard /> : <Navigate to="/" />} />
              <Route path="/report" element={role === 'citizen' ? <ReportIssuePage /> : <Navigate to="/" />} />
              <Route path="/profile" element={role === 'citizen' ? <ProfilePage /> : <Navigate to="/" />} />
              <Route path="/detail/:id" element={role ? <ComplaintDetailPage /> : <Navigate to="/login" />} />

              {/* Protected Admin Routes */}
              <Route path="/admin/dashboard" element={role === 'admin' ? <AdminDashboard /> : <Navigate to="/" />} />
              <Route path="/admin/detail/:id" element={role === 'admin' ? <ComplaintDetailPage /> : <Navigate to="/" />} />
              <Route path="/admin/duplicates" element={role === 'admin' ? <DuplicateDetectionPage /> : <Navigate to="/" />} />
              <Route path="/admin/hotspots" element={role === 'admin' ? <HotspotMapPage /> : <Navigate to="/" />} />
              <Route path="/admin/profile" element={role === 'admin' ? <AdminProfilePage /> : <Navigate to="/" />} />
            </Routes>
          </main>
          {role && <BottomNav role={role} />}
        </div>
      </Router>
    </AppContext.Provider>
  );
}
