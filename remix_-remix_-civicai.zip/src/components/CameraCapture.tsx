import React, { useRef, useState } from 'react';
import { Camera, X, Upload, Image as ImageIcon, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CameraCaptureProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  maxImages?: number;
}

export default function CameraCapture({ images, onImagesChange, maxImages = 3 }: CameraCaptureProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages = [...images];
    Array.from(files).forEach((file: File) => {
      if (newImages.length < maxImages) {
        const reader = new FileReader();
        reader.onloadend = () => {
          newImages.push(reader.result as string);
          onImagesChange([...newImages]);
        };
        reader.readAsDataURL(file);
      }
    });
  };

  const removeImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index);
    onImagesChange(newImages);
  };

  return (
    <section className="bg-white border border-outline-variant/30 rounded-2xl p-6 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold">Photo Evidence</h3>
        <span className="text-xs font-bold text-on-surface-variant opacity-60">
          {images.length} / {maxImages}
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
        <AnimatePresence mode="popLayout">
          {images.map((img, index) => (
            <motion.div
              key={index}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="aspect-square rounded-xl overflow-hidden relative border border-outline-variant/30 group"
            >
              <img src={img} alt={`Evidence ${index + 1}`} className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => removeImage(index)}
                className="absolute top-2 right-2 w-7 h-7 bg-error text-white rounded-full flex items-center justify-center shadow-lg transform translate-y-[-10px] opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all font-bold"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
          
          {images.length < maxImages && (
            <motion.div
              layout
              className="aspect-square"
            >
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-full border-2 border-dashed border-outline-variant rounded-xl flex flex-col items-center justify-center bg-surface-container-low/50 hover:bg-surface-container-low transition-colors cursor-pointer"
              >
                <Plus className="w-6 h-6 text-on-surface-variant opacity-40 mb-1" />
                <span className="text-[10px] font-bold text-on-surface-variant opacity-60 uppercase tracking-tighter">Add More</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {images.length === 0 ? (
        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={() => cameraInputRef.current?.click()}
            className="w-full py-6 border-2 border-dashed border-outline-variant rounded-xl flex flex-col items-center justify-center bg-surface-container-low/50 hover:bg-surface-container-low transition-colors group"
          >
            <div className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center mb-3 border border-outline-variant/30 group-hover:scale-110 transition-transform">
              <Camera className="w-6 h-6 text-on-surface-variant" />
            </div>
            <span className="font-bold text-on-surface text-sm">Take a Photo</span>
            <span className="text-[10px] text-on-surface-variant font-bold mt-1 uppercase tracking-widest opacity-60">Opens Camera</span>
          </button>
          
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-4 border border-outline-variant/30 rounded-xl flex items-center justify-center gap-2 bg-surface hover:bg-surface-container-low transition-colors font-bold text-sm text-on-surface-variant"
          >
            <Upload className="w-4 h-4" />
            Upload from Gallery
          </button>
        </div>
      ) : images.length < maxImages && (
        <div className="flex gap-2">
           <button
            type="button"
            onClick={() => cameraInputRef.current?.click()}
            className="flex-1 py-3 border border-outline-variant/30 rounded-xl flex items-center justify-center gap-2 bg-surface hover:bg-surface-container-low transition-colors font-bold text-xs text-on-surface-variant"
          >
            <Camera className="w-4 h-4" />
            Camera
          </button>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 py-3 border border-outline-variant/30 rounded-xl flex items-center justify-center gap-2 bg-surface hover:bg-surface-container-low transition-colors font-bold text-xs text-on-surface-variant"
          >
            <Upload className="w-4 h-4" />
            Gallery
          </button>
        </div>
      )}

      {/* Hidden Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />
    </section>
  );
}
