import React from 'react';
import { motion } from 'framer-motion';
import { 
  Droplets, 
  Trash2, 
  Zap, 
  ShieldAlert, 
  TrafficCone, 
  Trees, 
  Stethoscope, 
  Building2, 
  Dog, 
  Lightbulb, 
  Bus, 
  CloudRain, 
  Volume2, 
  HardHat, 
  HelpCircle,
  MapPin,
  PawPrint,
  LucideIcon
} from 'lucide-react';
import { cn } from '../lib/utils';

export type CategoryID = 
  | 'water' | 'roads' | 'sanitation' | 'electricity' | 'safety' 
  | 'traffic' | 'parks' | 'health' | 'infrastructure' | 'animals' 
  | 'lights' | 'transport' | 'drainage' | 'noise' | 'construction' | 'other';

export interface Category {
  id: CategoryID;
  label: string;
  icon: LucideIcon;
  hint: string;
}

export const CATEGORIES: Category[] = [
  { id: 'water', label: 'Water Supply', icon: Droplets, hint: "Describe water issue (e.g., no supply for 2 days, leaking pipe)" },
  { id: 'roads', label: 'Roads & Potholes', icon: MapPin, hint: "Describe road issue (e.g., large pothole near main road, broken divider)" },
  { id: 'sanitation', label: 'Garbage & Sanitation', icon: Trash2, hint: "Describe garbage issue (e.g., waste not collected, overflowing bin)" },
  { id: 'electricity', label: 'Electricity', icon: Zap, hint: "Describe electricity issue (e.g., frequent power cuts, low voltage)" },
  { id: 'safety', label: 'Public Safety', icon: ShieldAlert, hint: "Describe safety concern (e.g., suspicious activity, unsafe area)" },
  { id: 'traffic', label: 'Traffic Issues', icon: TrafficCone, hint: "Describe traffic issue (e.g., broken signal, heavy congestion)" },
  { id: 'parks', label: 'Parks & Environment', icon: Trees, hint: "Describe park issue (e.g., broken swings, neglected garden)" },
  { id: 'health', label: 'Health & Sanitation', icon: Stethoscope, hint: "Describe health concern (e.g., drainage leak near hospital, medical waste)" },
  { id: 'infrastructure', label: 'Public Infrastructure', icon: Building2, hint: "Describe building/facility issue (e.g., broken office door, wall cracks)" },
  { id: 'animals', label: 'Stray Animals', icon: PawPrint, hint: "Describe animal concern (e.g., stray dog menace, injured horse)" },
  { id: 'lights', label: 'Street Lights', icon: Lightbulb, hint: "Describe lighting issue (e.g., light not working, dim area)" },
  { id: 'transport', label: 'Public Transport', icon: Bus, hint: "Describe transport issue (e.g., bus delay, broken seat in metro)" },
  { id: 'drainage', label: 'Drainage & Flooding', icon: CloudRain, hint: "Describe drainage problem (e.g., clogged drain, water logging)" },
  { id: 'noise', label: 'Noise Pollution', icon: Volume2, hint: "Describe noise issue (e.g., loud music after midnight, factory noise)" },
  { id: 'construction', label: 'Construction Issues', icon: HardHat, hint: "Describe construction concern (e.g., debris on road, no safety fence)" },
  { id: 'other', label: 'Other', icon: HelpCircle, hint: "Describe the issue you've encountered..." },
];

interface CategoryCardProps {
  category: Category;
  isSelected: boolean;
  onSelect: (id: CategoryID) => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ category, isSelected, onSelect }) => {
  const Icon = category.icon;
  
  return (
    <motion.button
      type="button"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      onClick={() => onSelect(category.id)}
      className={cn(
        "flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-200 text-center gap-2 h-full min-h-[100px]",
        "bg-white shadow-sm",
        isSelected 
          ? "border-primary ring-2 ring-primary/20 shadow-md transform scale-[1.02]" 
          : "border-outline-variant/30 hover:border-outline-variant hover:shadow-md"
      )}
    >
      <div className={cn(
        "p-2 rounded-xl transition-colors",
        isSelected ? "bg-primary text-white" : "bg-surface-container text-on-surface-variant"
      )}>
        <Icon className="w-6 h-6 md:w-7 md:h-7" />
      </div>
      <span className={cn(
        "text-xs md:text-sm font-bold leading-tight",
        isSelected ? "text-primary" : "text-on-surface-variant"
      )}>
        {category.label}
      </span>
    </motion.button>
  );
};

interface CategoryGridProps {
  selectedId: CategoryID | null;
  onSelect: (id: CategoryID) => void;
}

export const CategoryGrid: React.FC<CategoryGridProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-4 mt-2">
      {CATEGORIES.map((cat) => (
        <CategoryCard 
          key={cat.id} 
          category={cat} 
          isSelected={selectedId === cat.id} 
          onSelect={onSelect} 
        />
      ))}
    </div>
  );
};
