import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, MapPin, Loader2, Bot, User as UserIcon, CheckCircle2, AlertCircle, Mic, Camera, Paperclip } from 'lucide-react';
import { aiService, AIAnalysisResult } from '../services/aiService';
import { issueService } from '../services/issueService';
import { useApp } from '../App';
import { CategoryID } from './CategorySelection';
import { cn } from '../lib/utils';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'system';
  timestamp: Date;
  analysis?: AIAnalysisResult & {
    department: string;
    assignedTo: string;
    action: string;
    locationLabel: string;
  };
}

const DEPT_MAPPING: Record<string, string> = {
  'Road': 'Road Department',
  'Electricity': 'Electrical Department',
  'Water': 'Water Supply Department',
  'Garbage': 'Sanitation Department',
  'roads': 'Road Department',
  'electricity': 'Electrical Department',
  'water': 'Water Supply Department',
  'sanitation': 'Sanitation Department'
};

const ACTION_MAPPING: Record<string, string> = {
  'Road': 'Repair within 24 hours',
  'Electricity': 'Fix within 12 hours',
  'Water': 'Resolve within 24 hours',
  'Garbage': 'Clean within 8 hours',
  'roads': 'Repair within 24 hours',
  'electricity': 'Fix within 12 hours',
  'water': 'Resolve within 24 hours',
  'sanitation': 'Clean within 8 hours'
};

export default function CivicChatbot() {
  const { user } = useApp();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationName, setLocationName] = useState('Detecting location...');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial greeting
    setMessages([
      {
        id: '1',
        text: "Hello! I'm your CivicAI assistant. How can I help you today? Please describe the issue you've encountered.",
        sender: 'system',
        timestamp: new Date()
      }
    ]);

    // Get location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setLocation(coords);
          setLocationName(`${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}`);
        },
        () => {
          // Fallback to Shimoga
          const fallback = { lat: 13.3409, lng: 75.5690 };
          setLocation(fallback);
          setLocationName("Shimoga (Fallback)");
        }
      );
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userText = inputValue.trim();
    setInputValue('');
    
    const userMsg: Message = {
      id: Date.now().toString(),
      text: userText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      // 1. Analyze with AI
      const analysis = await aiService.analyzeComplaint(userText);
      
      // 2. Map Department
      const department = DEPT_MAPPING[analysis.category] || 'General Works Department';
      
      // 3. Routing Logic
      const assignedTo = (location?.lat || 0) > 13.3 ? 'Zone A Engineer' : 'Zone B Engineer';
      
      // 4. Action Generation
      const action = ACTION_MAPPING[analysis.category] || 'Resolve within 48 hours';

      // 5. Create Issue in DB (optional, but requested "CORE FLOW (STRICT)")
      if (user) {
        await issueService.createIssue({
          title: `${analysis.category} - ${analysis.subcategory}`,
          summary: userText,
          category: (analysis.category.toLowerCase()) as any,
          location: locationName,
          latitude: location?.lat || null,
          longitude: location?.lng || null,
          authorId: user.id,
          authorName: user.name,
        });
      }

      const systemMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: `Complaint Analyzed! Here are the details:`,
        sender: 'system',
        timestamp: new Date(),
        analysis: {
          ...analysis,
          department,
          assignedTo,
          action,
          locationLabel: locationName
        }
      };

      setMessages(prev => [...prev, systemMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I encountered an error while processing your complaint. Please try again.",
        sender: 'system',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority?.toLowerCase()) {
      case 'high': return 'bg-red-50 text-red-600 border-red-200';
      case 'medium': return 'bg-amber-50 text-amber-600 border-amber-200';
      case 'low': return 'bg-emerald-50 text-emerald-600 border-emerald-200';
      default: return 'bg-slate-50 text-slate-600 border-slate-200';
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col w-full max-w-[420px] h-[650px] mx-auto bg-white rounded-3xl border border-outline-variant/20 shadow-xl overflow-hidden"
    >
      {/* Header */}
      <div className="bg-primary px-5 py-4 text-white flex items-center justify-between shadow-md z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold">CivicAI Assistant</h3>
            <div className="flex items-center gap-1.5 text-[10px] opacity-80 uppercase tracking-widest font-bold">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              Online
            </div>
          </div>
        </div>
        <div className="text-[10px] text-white/60 font-bold flex flex-col items-end">
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" />
            {locationName}
          </span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-surface-container-low/30">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={cn(
                "flex flex-col max-w-[85%]",
                msg.sender === 'user' ? "ml-auto items-end" : "mr-auto items-start"
              )}
            >
              <div className={cn(
                "p-3.5 rounded-2xl text-sm font-medium shadow-sm transition-all duration-300",
                msg.sender === 'user' 
                  ? "bg-primary text-white rounded-tr-none" 
                  : "bg-surface-container-low border border-outline-variant/20 text-on-surface rounded-tl-none"
              )}>
                {msg.text}
              </div>
              
              {msg.analysis && (
                <motion.div 
                  initial={{ opacity: 0, height: 0, y: 10 }}
                  animate={{ opacity: 1, height: 'auto', y: 0 }}
                  className="mt-2 w-full bg-white border border-outline-variant/30 rounded-2xl p-4 shadow-inner space-y-3 relative overflow-hidden group"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />
                  
                   <div className="flex items-center justify-between border-b border-outline-variant/10 pb-2 relative z-10">
                    <span className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">Analysis Results</span>
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase border",
                      getPriorityColor(msg.analysis.priority)
                    )}>
                      {msg.analysis.priority} {msg.analysis.priority.toLowerCase() === 'high' ? '🚨' : ''}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-on-surface-variant opacity-60 mb-0.5">Category</label>
                      <p className="font-bold capitalize">{msg.analysis.category}</p>
                    </div>
                    <div>
                      <label className="block text-on-surface-variant opacity-60 mb-0.5">Department</label>
                      <p className="font-bold">{msg.analysis.department}</p>
                    </div>
                    <div>
                      <label className="block text-on-surface-variant opacity-60 mb-0.5">Assigned To</label>
                      <p className="font-bold text-secondary">{msg.analysis.assignedTo}</p>
                    </div>
                    <div>
                      <label className="block text-on-surface-variant opacity-60 mb-0.5">Recommended Action</label>
                      <p className="font-bold text-primary">{msg.analysis.action}</p>
                    </div>
                  </div>
                  
                  <div className="pt-2 border-t border-outline-variant/10">
                    <label className="block text-on-surface-variant opacity-60 text-xs mb-0.5">AI Reasoning</label>
                    <p className="text-xs italic text-on-surface-variant">{msg.analysis.reason}</p>
                  </div>
                  
                  <div className="flex items-center gap-2 text-green-600 text-[10px] font-bold uppercase bg-green-50 px-2 py-1.5 rounded-lg border border-green-100">
                    <CheckCircle2 className="w-3 h-3" />
                    Complaint successfully routed & logged
                  </div>
                </motion.div>
              )}
              
              <span className="text-[10px] text-on-surface-variant mt-1 px-1 opacity-60 font-bold">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 text-primary font-bold text-xs p-3 bg-white border border-outline-variant/20 rounded-2xl w-fit shadow-sm"
            >
              <div className="flex gap-1">
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }} 
                  transition={{ repeat: Infinity, duration: 0.6 }} 
                  className="w-1.5 h-1.5 rounded-full bg-primary" 
                />
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }} 
                  transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} 
                  className="w-1.5 h-1.5 rounded-full bg-primary" 
                />
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }} 
                  transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} 
                  className="w-1.5 h-1.5 rounded-full bg-primary" 
                />
              </div>
              <span className="ml-1 uppercase tracking-widest text-[10px]">AI Analyzing</span>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="px-4 py-4 bg-white border-t border-outline-variant/10 shadow-[0_-4px_12px_rgba(0,0,0,0.03)]">
        <div className="flex items-center gap-2 mb-2 px-1">
          <button className="p-2 text-on-surface-variant hover:bg-surface-container transition-colors rounded-full opacity-60 hover:opacity-100">
            <Mic className="w-5 h-5" />
          </button>
          <button className="p-2 text-on-surface-variant hover:bg-surface-container transition-colors rounded-full opacity-60 hover:opacity-100">
            <Camera className="w-5 h-5" />
          </button>
          <button className="p-2 text-on-surface-variant hover:bg-surface-container transition-colors rounded-full opacity-60 hover:opacity-100">
            <Paperclip className="w-5 h-5" />
          </button>
        </div>
        <div className="relative flex items-center">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Describe your civic issue..."
            disabled={isLoading}
            className="flex-1 bg-surface-container-lowest border border-outline-variant/40 rounded-2xl py-3.5 pl-5 pr-14 focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none transition-all text-sm font-medium shadow-inner"
          />
          <button
            onClick={handleSend}
            disabled={!inputValue.trim() || isLoading}
            className="absolute right-1.5 w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center hover:shadow-lg active:scale-95 transition-all disabled:opacity-30 disabled:shadow-none"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </motion.div>
  );
}
