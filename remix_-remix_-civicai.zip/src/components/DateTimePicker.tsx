import React from 'react';
import { Calendar, Clock } from 'lucide-react';

interface DateTimePickerProps {
  date: string;
  time: string;
  onDateChange: (date: string) => void;
  onTimeChange: (time: string) => void;
}

export default function DateTimePicker({ date, time, onDateChange, onTimeChange }: DateTimePickerProps) {
  const handleNow = () => {
    const now = new Date();
    onDateChange(now.toISOString().split('T')[0]);
    onTimeChange(now.toTimeString().split(' ')[0].substring(0, 5));
  };

  return (
    <section className="bg-white border border-outline-variant/30 rounded-2xl p-6 shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-bold">When did this happen?</h3>
        <button
          type="button"
          onClick={handleNow}
          className="text-xs font-bold text-on-tertiary-container bg-surface-container px-3 py-1.5 rounded-lg hover:bg-surface-container-high transition-colors"
        >
          Set to Now
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5" />
            Date
          </label>
          <input
            type="date"
            value={date}
            onChange={(e) => onDateChange(e.target.value)}
            max={new Date().toISOString().split('T')[0]}
            className="w-full bg-surface-bright border border-outline-variant/50 rounded-xl p-3 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-medium text-sm"
          />
        </div>
        
        <div className="space-y-2">
          <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-3.5 h-3.5" />
            Time
          </label>
          <input
            type="time"
            value={time}
            onChange={(e) => onTimeChange(e.target.value)}
            className="w-full bg-surface-bright border border-outline-variant/50 rounded-xl p-3 focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-medium text-sm"
          />
        </div>
      </div>
    </section>
  );
}
