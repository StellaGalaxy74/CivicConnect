import React, { useState } from 'react';
import { Truck, Send, Loader2, AlertCircle, X, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DispatchPanelProps {
  onDispatch: (team: string) => Promise<void>;
  isLoading: boolean;
  category: string;
}

const TEAMS_BY_CATEGORY: Record<string, string[]> = {
  sanitation: ['Waste Management Team A', 'Sanitation Quick Response', 'Eco-Clean Unit'],
  roads: ['Asphalt Repair Crew', 'Street Maintenance Dept', 'Traffic Safety Unit'],
  water: ['Hydraulic Services RRU', 'Plumbing Maintenance', 'Water Quality Control'],
  electricity: ['Grid Repair Team', 'Electrical Safety Unit', 'Public Lighting Dept'],
  other: ['General Maintenance', 'Municipal Task Force', 'Emergency Response Unit']
};

export default function DispatchPanel({ onDispatch, isLoading, category }: DispatchPanelProps) {
  const [selectedTeam, setSelectedTeam] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const teams = TEAMS_BY_CATEGORY[category] || TEAMS_BY_CATEGORY.other;

  const handleConfirmDispatch = async () => {
    if (!selectedTeam) return;
    await onDispatch(selectedTeam);
    setShowConfirm(false);
  };

  return (
    <section className="bg-white p-8 rounded-2xl border border-outline-variant/30 shadow-sm">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-on-tertiary-container/10 rounded-lg text-on-tertiary-container">
          <Truck className="w-5 h-5" />
        </div>
        <h3 className="text-xl font-bold tracking-tight">Dispatch Response Team</h3>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest mb-2 block opacity-60">
            Select Response Unit
          </label>
          <select
            value={selectedTeam}
            onChange={(e) => setSelectedTeam(e.target.value)}
            disabled={isLoading}
            className="w-full h-12 px-4 bg-surface-container-low border border-outline-variant/30 rounded-xl focus:ring-2 focus:ring-primary/10 outline-none transition-all font-bold text-sm"
          >
            <option value="">choose a team...</option>
            {teams.map(team => (
              <option key={team} value={team}>{team}</option>
            ))}
          </select>
        </div>

        <button
          onClick={() => setShowConfirm(true)}
          disabled={!selectedTeam || isLoading}
          className="w-full h-12 bg-on-tertiary-container text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-on-tertiary-container/90 transition-all flex items-center justify-center gap-2 group disabled:opacity-50"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <>
              Initialize Dispatch
              <Send className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </>
          )}
        </button>
      </div>

      <AnimatePresence>
        {showConfirm && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowConfirm(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div className="p-3 bg-on-tertiary-container/10 rounded-2xl text-on-tertiary-container">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <button 
                    onClick={() => setShowConfirm(false)}
                    className="p-2 hover:bg-surface-container rounded-full transition-colors"
                  >
                    <X className="w-5 h-5 text-on-surface-variant opacity-40" />
                  </button>
                </div>

                <h3 className="text-2xl font-black tracking-tight mb-2">Confirm Deployment?</h3>
                <p className="text-on-surface-variant font-medium leading-relaxed mb-8">
                  You are about to authorize the immediate dispatch of <span className="font-bold text-primary underline decoration-primary/20 underline-offset-4">{selectedTeam}</span> to handle this {category} incident.
                </p>

                <div className="bg-surface-container/50 rounded-2xl p-4 mb-8 border border-outline-variant/10">
                  <div className="flex items-center gap-3">
                    <AlertCircle className="w-5 h-5 text-on-tertiary-container flex-shrink-0" />
                    <p className="text-[10px] font-black uppercase tracking-widest text-on-tertiary-container opacity-60">
                      Standard operation protocol will be activated automatically.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <button
                    onClick={handleConfirmDispatch}
                    disabled={isLoading}
                    className="h-14 bg-on-tertiary-container text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-on-tertiary-container/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    {isLoading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        Confirm & Deploy Unit
                        <Send className="w-4 h-4" />
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => setShowConfirm(false)}
                    className="h-14 bg-surface-container rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-surface-container-high transition-all"
                  >
                    Cancel Action
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
