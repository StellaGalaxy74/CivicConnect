import { Link, useLocation } from 'react-router-dom';
import { Home, ClipboardList, Bell, User, LayoutDashboard, Map as MapIcon, TriangleAlert, Settings, LogOut, Menu, X, ShieldCheck, EyeOff, Eye } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { useApp } from '../App';

export function Navbar({ role, user }: { role: string | null; user: any }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { switchRole } = useApp();
  
  return (
    <nav className="fixed top-0 w-full z-50 border-b border-outline-variant/30 bg-white/95 backdrop-blur-md shadow-sm">
      {user?.role === 'admin' && role === 'citizen' && (
        <div className="bg-primary text-white py-1 px-4 flex justify-center items-center gap-4 animate-in slide-in-from-top duration-500">
          <span className="text-[9px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            Active Impersonation: Citizen Perspective
          </span>
          <button 
            onClick={() => switchRole('admin')}
            className="bg-white text-primary px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest hover:bg-surface transition-all flex items-center gap-1.5"
          >
            <EyeOff className="w-3 h-3" />
            Switch Back
          </button>
        </div>
      )}
      <div className="flex justify-between items-center h-16 px-4 w-full max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white ring-2 ring-primary/10">
              <ClipboardList className="w-5 h-5" />
            </span>
            <span className="text-xl font-extrabold text-on-surface tracking-tighter font-display">CivicAI</span>
          </Link>
          
          {role === 'citizen' && (
            <div className="hidden md:flex ml-8 items-center gap-6">
              <Link to="/dashboard" className="text-on-surface font-semibold text-sm">Dashboard</Link>
              <Link to="/report" className="text-on-surface-variant hover:text-on-surface text-sm transition-colors">Reports</Link>
              <Link to="/profile" className="text-on-surface-variant hover:text-on-surface text-sm transition-colors">Profile</Link>
            </div>
          )}

          {role === 'admin' && (
            <div className="hidden md:flex ml-8 items-center gap-6">
              <Link to="/admin/dashboard" className="text-on-surface font-semibold text-sm">Command Center</Link>
              <Link to="/admin/hotspots" className="text-on-surface-variant hover:text-on-surface text-sm transition-colors">Hotspots</Link>
              <Link to="/admin/duplicates" className="text-on-surface-variant hover:text-on-surface text-sm transition-colors">Duplicates</Link>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <button className="p-2 text-on-surface hover:bg-surface-container rounded-full transition-colors relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error rounded-full ring-2 ring-white"></span>
          </button>
          
          {user && (
            <Link to={role === 'admin' ? '/admin/profile' : '/profile'} className="flex items-center gap-2">
               <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant/50">
                <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
              </div>
            </Link>
          )}

          <button 
            className="md:hidden p-2 text-on-surface hover:bg-surface-container rounded-lg"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-16 left-0 w-full bg-white border-b border-outline-variant shadow-xl p-4 space-y-4"
          >
            {role === 'citizen' ? (
              <>
                <Link to="/dashboard" onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-surface-container font-semibold">Dashboard</Link>
                <Link to="/report" onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-surface-container">Report Issue</Link>
                <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-surface-container">Profile</Link>
              </>
            ) : (
              <>
                <Link to="/admin/dashboard" onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-surface-container font-semibold">Admin Dashboard</Link>
                <Link to="/admin/hotspots" onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-surface-container">Hotspot Map</Link>
                <Link to="/admin/duplicates" onClick={() => setIsMobileMenuOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-surface-container">Duplicate Detection</Link>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export function BottomNav({ role }: { role: string | null }) {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  if (role === 'citizen') {
    return (
      <nav className="md:hidden fixed bottom-0 left-0 w-full h-20 bg-white/95 backdrop-blur-md border-t border-outline-variant/30 flex justify-around items-center px-2 pb-safe z-50">
        <Link to="/dashboard" className={cn("flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all", isActive('/dashboard') ? "text-primary bg-surface-container" : "text-on-surface-variant")}>
          <LayoutDashboard className={cn("w-6 h-6", isActive('/dashboard') && "fill-current")} />
          <span className="text-[10px] font-bold uppercase tracking-widest font-display">Dashboard</span>
        </Link>
        <Link to="/report" className={cn("flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all", isActive('/report') ? "text-primary bg-surface-container" : "text-on-surface-variant")}>
          <ClipboardList className={cn("w-6 h-6", isActive('/report') && "fill-current")} />
          <span className="text-[10px] font-bold uppercase tracking-widest font-display">Reports</span>
        </Link>
        <Link to="/profile" className={cn("flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all", isActive('/profile') ? "text-primary bg-surface-container" : "text-on-surface-variant")}>
          <User className={cn("w-6 h-6", isActive('/profile') && "fill-current")} />
          <span className="text-[10px] font-bold uppercase tracking-widest font-display">Profile</span>
        </Link>
      </nav>
    );
  }

  if (role === 'admin') {
     return (
      <nav className="md:hidden fixed bottom-0 left-0 w-full h-20 bg-white/95 backdrop-blur-md border-t border-outline-variant/30 flex justify-around items-center px-2 pb-safe z-50">
        <Link to="/admin/dashboard" className={cn("flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all", isActive('/admin/dashboard') ? "text-primary bg-surface-container" : "text-on-surface-variant")}>
          <LayoutDashboard className={cn("w-6 h-6", isActive('/admin/dashboard') && "fill-current")} />
          <span className="text-[10px] font-bold uppercase tracking-widest font-display">Hub</span>
        </Link>
        <Link to="/admin/hotspots" className={cn("flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all", isActive('/admin/hotspots') ? "text-primary bg-surface-container" : "text-on-surface-variant")}>
          <MapIcon className={cn("w-6 h-6", isActive('/admin/hotspots') && "fill-current")} />
          <span className="text-[10px] font-bold uppercase tracking-widest font-display">Map</span>
        </Link>
        <Link to="/admin/profile" className={cn("flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all", isActive('/admin/profile') ? "text-primary bg-surface-container" : "text-on-surface-variant")}>
          <Settings className={cn("w-6 h-6", isActive('/admin/profile') && "fill-current")} />
          <span className="text-[10px] font-bold uppercase tracking-widest font-display">Admin</span>
        </Link>
      </nav>
    );
  }

  return null;
}

export function AdminSidebar() {
  const location = useLocation();
  const { switchRole } = useApp();
  const isActive = (path: string) => location.pathname === path;

  const links = [
    { name: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
    { name: 'Duplicate Detection', path: '/admin/duplicates', icon: ClipboardList },
    { name: 'Hotspot Map', path: '/admin/hotspots', icon: MapIcon },
    { name: 'Settings', path: '/admin/profile', icon: Settings },
  ];

  return (
    <aside className="hidden md:flex flex-col fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-outline-variant/30 bg-white p-6 pt-10">
      <div className="mb-8">
        <h2 className="text-xs font-bold text-on-surface-variant uppercase tracking-widest mb-4">Governance Suite</h2>
        <nav className="space-y-1">
          {links.map((link) => (
            <Link 
              key={link.path}
              to={link.path}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all font-display text-sm font-semibold",
                isActive(link.path) 
                  ? "bg-surface-container text-primary border-r-4 border-primary" 
                  : "text-on-surface-variant hover:bg-surface-container/50 hover:text-on-surface"
              )}
            >
              <link.icon className={cn("w-5 h-5", isActive(link.path) && "fill-current")} />
              {link.name}
            </Link>
          ))}
        </nav>
      </div>

      <div className="mt-auto pt-6 border-t border-outline-variant/30 space-y-4">
        <div className="px-4 py-3 bg-surface-container-low rounded-xl border border-outline-variant/20">
          <p className="text-[9px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-3">System Context</p>
          <button 
            onClick={() => switchRole('citizen')}
            className="flex items-center gap-2 w-full px-3 py-2 bg-white border border-outline-variant/30 rounded-lg text-[10px] font-black uppercase tracking-widest text-primary hover:bg-primary hover:text-white transition-all group/toggle shadow-sm"
          >
            <Eye className="w-3.5 h-3.5 group-hover/toggle:scale-110 transition-transform" />
            Citizen View
          </button>
        </div>
        <button className="flex items-center gap-3 px-4 py-3 w-full rounded-lg text-error hover:bg-error/5 font-display text-sm font-semibold transition-all">
          <LogOut className="w-5 h-5" />
          Logout
        </button>
        <p className="text-[10px] text-on-surface-variant/40 mt-4 font-bold uppercase tracking-widest">Version 1.0.4</p>
      </div>
    </aside>
  );
}
