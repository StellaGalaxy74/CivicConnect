import React, { useState } from 'react';
import { CheckCircle2, ClipboardCheck, Play, CheckCircle } from 'lucide-react';
import { IssueStatus } from '../types';
import { cn } from '../lib/utils';

interface StatusActionsProps {
  currentStatus: IssueStatus;
  onUpdateStatus: (newStatus: IssueStatus, message: string) => Promise<void>;
  isLoading: boolean;
}

const TRANSITIONS: Record<IssueStatus, { next: IssueStatus; label: string; icon: any; color: string; message: string } | null> = {
  SUBMITTED: { 
    next: 'REVIEWED', 
    label: 'Mark as Reviewed', 
    icon: ClipboardCheck, 
    color: 'bg-on-tertiary-container',
    message: 'Complaint has been reviewed by the administrative team.'
  },
  REVIEWED: { 
    next: 'ASSIGNED', 
    label: 'Assign Team', 
    icon: CheckCircle2, 
    color: 'bg-primary',
    message: 'Complaint assigned to a response unit.'
  },
  ASSIGNED: { 
    next: 'IN_PROGRESS', 
    label: 'Start Work', 
    icon: Play, 
    color: 'bg-secondary',
    message: 'Response team has commenced work on site.'
  },
  IN_PROGRESS: { 
    next: 'RESOLVED', 
    label: 'Mark as Resolved', 
    icon: CheckCircle, 
    color: 'bg-secondary',
    message: 'Issue has been successfully resolved.'
  },
  RESOLVED: null
};

export default function StatusActions({ currentStatus, onUpdateStatus, isLoading }: StatusActionsProps) {
  const [showConfirm, setShowConfirm] = useState(false);
  const transition = TRANSITIONS[currentStatus];

  if (!transition) return (
    <div className="flex items-center gap-2 text-secondary font-bold text-sm bg-secondary/10 px-4 py-2 rounded-xl border border-secondary/20">
      <CheckCircle className="w-4 h-4" />
      Case Fully Resolved
    </div>
  );

  const handleAction = async () => {
    if (showConfirm) {
      await onUpdateStatus(transition.next, transition.message);
      setShowConfirm(false);
    } else {
      setShowConfirm(true);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        {showConfirm ? (
          <div className="flex items-center gap-2 animate-in fade-in slide-in-from-right-2">
            <button
              disabled={isLoading}
              onClick={handleAction}
              className="px-6 h-12 bg-primary text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-primary/90 transition-all flex items-center gap-2"
            >
              {isLoading ? 'Updating...' : 'Confirm Action'}
            </button>
            <button
              disabled={isLoading}
              onClick={() => setShowConfirm(false)}
              className="px-4 h-12 bg-surface-container border border-outline-variant/30 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-surface-container-high transition-all"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            disabled={isLoading || (currentStatus === 'REVIEWED')} // Assignment usually handled by dispatch panel
            onClick={handleAction}
            className={cn(
              "px-6 h-12 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg transition-all flex items-center gap-2 group active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed",
              transition.color
            )}
          >
            <transition.icon className="w-4 h-4 group-hover:scale-110 transition-transform" />
            {transition.label}
          </button>
        )}
      </div>
      {showConfirm && (
        <p className="text-[10px] font-bold text-error uppercase tracking-tight ml-1 animate-pulse italic">
          Are you sure you want to transition to {transition.next}?
        </p>
      )}
    </div>
  );
}
