import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Clock, ArrowRight, Eye, UserPlus, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Issue } from '../../types';
import { cn } from '../../lib/utils';

interface ComplaintCardProps {
  issue: Issue;
  onAssign?: (id: string) => void;
  onResolve?: (id: string) => void;
  compact?: boolean;
}

export default function ComplaintCard({ issue, onAssign, onResolve, compact = false }: ComplaintCardProps) {
  const statusColors = {
    SUBMITTED: 'bg-surface-container text-on-surface-variant',
    REVIEWED: 'bg-primary/10 text-primary',
    ASSIGNED: 'bg-secondary/10 text-secondary',
    IN_PROGRESS: 'bg-secondary text-white',
    RESOLVED: 'bg-primary text-white'
  };

  const priorityColors = {
    urgent: 'bg-error text-white',
    high: 'bg-error/10 text-error',
    medium: 'bg-secondary/10 text-secondary',
    low: 'bg-surface-container text-on-surface-variant'
  };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      className={cn(
        "bg-white border border-outline-variant/30 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all group",
        issue.priority === 'urgent' && "border-error/20 ring-1 ring-error/5"
      )}
    >
      <div className="flex flex-col gap-4">
        {/* Header Information */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className={cn(
                "px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest",
                statusColors[issue.status]
              )}>
                {issue.status}
              </span>
              <span className={cn(
                "px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest",
                priorityColors[issue.priority]
              )}>
                {issue.priority}
              </span>
              <span className="text-[9px] font-bold text-on-surface-variant/40">#{issue.id.slice(-6).toUpperCase()}</span>
            </div>
            <h3 className="font-bold text-base leading-tight group-hover:text-primary transition-colors truncate">
              {issue.title || issue.summary}
            </h3>
          </div>
          <div className="hidden sm:flex flex-col items-end gap-1">
             <div className="flex items-center gap-1.5 text-[10px] font-bold text-on-surface-variant/60">
              <Clock className="w-3 h-3" />
              {issue.timestamp}
            </div>
          </div>
        </div>

        {/* Location & Details */}
        {!compact && (
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2 text-xs font-medium text-on-surface-variant">
              <MapPin className="w-3.5 h-3.5 text-primary/60" />
              <span className="truncate">{issue.location}</span>
            </div>
            <p className="text-xs text-on-surface-variant/70 line-clamp-1 italic">
              "{issue.summary}"
            </p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-surface-container-high/50">
          <div className="flex items-center gap-1">
            <Link 
              to={`/admin/detail/${issue.id}`}
              className="px-3 py-2 bg-surface-container hover:bg-surface-container-high rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" />
              View
            </Link>
            
            {issue.status === 'REVIEWED' && onAssign && (
              <button 
                onClick={() => onAssign(issue.id)}
                className="px-3 py-2 text-primary hover:bg-primary/5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-1.5"
              >
                <UserPlus className="w-3.5 h-3.5" />
                Assign
              </button>
            )}

            {issue.status === 'IN_PROGRESS' && onResolve && (
              <button 
                onClick={() => onResolve(issue.id)}
                className="px-3 py-2 text-secondary hover:bg-secondary/5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Resolve
              </button>
            )}
          </div>
          
          <Link to={`/admin/detail/${issue.id}`} className="text-on-surface-variant/30 hover:text-primary transition-colors">
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
