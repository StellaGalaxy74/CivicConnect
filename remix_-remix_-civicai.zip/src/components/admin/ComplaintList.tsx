import React from 'react';
import { motion } from 'motion/react';
import ComplaintCard from './ComplaintCard';
import { Issue } from '../../types';
import { FolderSearch } from 'lucide-react';

interface ComplaintListProps {
  issues: Issue[];
  title: string;
  subtitle?: string;
  limit?: number;
  emptyMessage?: string;
  onAssign?: (id: string) => void;
  onResolve?: (id: string) => void;
  compact?: boolean;
}

export default function ComplaintList({ 
  issues, 
  title, 
  subtitle, 
  limit, 
  emptyMessage = "No relevant complaints found.",
  onAssign,
  onResolve,
  compact = false
}: ComplaintListProps) {
  const displayIssues = limit ? issues.slice(0, limit) : issues;

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between px-2">
        <div>
          <h2 className="text-xl font-black tracking-tight text-on-surface">{title}</h2>
          {subtitle && <p className="text-[10px] font-black uppercase tracking-widest opacity-40">{subtitle}</p>}
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest text-primary bg-primary/5 px-2 py-1 rounded-lg">
          {issues.length} Total
        </span>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {displayIssues.length > 0 ? (
          displayIssues.map((issue, idx) => (
            <motion.div
              key={issue.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
            >
              <ComplaintCard 
                issue={issue} 
                compact={compact} 
                onAssign={onAssign}
                onResolve={onResolve}
              />
            </motion.div>
          ))
        ) : (
          <div className="py-12 bg-surface-container-low rounded-3xl border-2 border-dashed border-outline-variant/20 flex flex-col items-center justify-center text-center px-6">
            <div className="w-16 h-16 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant/30 mb-4">
              <FolderSearch className="w-8 h-8" />
            </div>
            <p className="text-sm font-bold text-on-surface-variant opacity-60 max-w-xs">{emptyMessage}</p>
          </div>
        )}
      </div>
    </div>
  );
}
