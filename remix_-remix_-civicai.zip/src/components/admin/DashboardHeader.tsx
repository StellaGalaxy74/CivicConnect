import React from 'react';
import { Search, Filter, Eye, User } from 'lucide-react';
import { useApp } from '../../App';

export default function DashboardHeader() {
  const { switchRole, user } = useApp();

  return (
    <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/60">CivicFix AI</span>
          <div className="w-1 h-1 rounded-full bg-outline-variant/30" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface-variant opacity-40">Command Center</span>
        </div>
        <h1 className="text-3xl font-black tracking-tight text-primary">Admin Dashboard</h1>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative group hidden sm:block">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-outline w-4 h-4 group-focus-within:text-primary transition-colors" />
          <input 
            type="text" 
            placeholder="Quick search..."
            className="pl-10 pr-4 h-11 w-48 lg:w-64 bg-surface-container-low border border-outline-variant/30 rounded-xl focus:ring-4 focus:ring-primary/5 focus:border-primary outline-none transition-all text-sm font-medium"
          />
        </div>
        
        <button 
          onClick={() => switchRole('citizen')}
          className="flex items-center gap-2 h-11 px-5 bg-white border border-outline-variant/50 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-surface-container transition-all shadow-sm group"
        >
          <Eye className="w-4 h-4 group-hover:scale-110 transition-transform" />
          <span className="hidden lg:inline">Citizen View</span>
        </button>

        <div className="h-11 w-11 rounded-xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
          <User className="w-5 h-5" />
        </div>
      </div>
    </header>
  );
}
