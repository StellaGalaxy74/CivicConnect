import React, { useState } from 'react';
import { Maximize2, X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ImageGalleryProps {
  images: string[];
}

export default function ImageGallery({ images }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  if (!images || images.length === 0) return (
    <div className="bg-surface-container-low rounded-2xl p-12 text-center border-2 border-dashed border-outline-variant/30">
      <p className="text-sm font-bold text-on-surface-variant opacity-60 uppercase tracking-widest">No Visual Evidence Provided</p>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold tracking-tight">Image Proof</h3>
        <span className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-40">{images.length} Photos</span>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x">
        {images.map((img, idx) => (
          <motion.div
            key={idx}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedImage(img)}
            className="flex-shrink-0 w-64 aspect-square bg-surface-container rounded-2xl overflow-hidden cursor-zoom-in border border-outline-variant/30 shadow-sm snap-start group relative"
          >
            <img 
              src={img} 
              alt={`Evidence ${idx + 1}`} 
              className="w-full h-full object-cover group-hover:brightness-90 transition-all duration-500"
            />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Maximize2 className="text-white w-8 h-8 drop-shadow-lg" />
            </div>
            <div className="absolute bottom-3 left-3 bg-black/40 backdrop-blur-md px-2 py-1 rounded-lg">
              <span className="text-[9px] font-black text-white uppercase tracking-tighter">PROOF #{idx + 1}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-10"
            onClick={() => setSelectedImage(null)}
          >
            <button 
              className="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors z-[110]"
              onClick={(e) => { e.stopPropagation(); setSelectedImage(null); }}
            >
              <X className="w-6 h-6" />
            </button>
            
            <motion.div
              layoutId="fullscreen-img"
              className="relative max-w-5xl w-full h-full flex items-center justify-center"
              onClick={(e) => e.stopPropagation()}
            >
              <img 
                src={selectedImage} 
                alt="Fullscreen evidence" 
                className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 flex justify-center">
                <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-2xl flex items-center gap-4">
                  <ZoomIn className="w-4 h-4 text-white opacity-60" />
                  <span className="text-white text-xs font-bold uppercase tracking-widest">Inspection Mode Active</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
