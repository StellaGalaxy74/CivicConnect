import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { MapPin, Navigation, ExternalLink } from 'lucide-react';

// Fix for default marker icon in Leaflet
// @ts-ignore
import icon from 'leaflet/dist/images/marker-icon.png';
// @ts-ignore
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapViewProps {
  lat?: number | null;
  lng?: number | null;
  address?: string;
  category?: string;
}

export default function MapView({ lat, lng, address, category }: MapViewProps) {
  const hasCoords = lat !== null && lng !== null && lat !== undefined && lng !== undefined;
  const position: [number, number] = hasCoords ? [lat, lng] : [51.505, -0.09]; // Fallback

  const openInGoogleMaps = () => {
    if (hasCoords) {
      window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
    } else if (address) {
      window.open(`https://www.google.com/maps?q=${encodeURIComponent(address)}`, '_blank');
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-outline-variant/30 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-surface-container flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-on-secondary-container/10 rounded-lg text-on-secondary-container">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight">Geo-Visualization</h3>
            <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Verified GPS Coordinates</p>
          </div>
        </div>
        <button 
          onClick={openInGoogleMaps}
          className="flex items-center gap-2 px-4 py-2 bg-surface-container hover:bg-surface-container-high rounded-xl text-xs font-bold transition-all"
        >
          <ExternalLink className="w-3 h-3" />
          Open in Maps
        </button>
      </div>

      <div className="h-[400px] relative z-0">
        {hasCoords ? (
          <MapContainer 
            center={position} 
            zoom={15} 
            scrollWheelZoom={false}
            className="h-full w-full"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Circle 
              center={position} 
              radius={100} 
              pathOptions={{ fillColor: 'var(--color-primary)', color: 'var(--color-primary)', opacity: 0.3, fillOpacity: 0.1 }} 
            />
            <Marker position={position}>
              <Popup>
                <div className="p-2">
                  <p className="font-bold text-sm mb-1 uppercase tracking-tight">{category} Incident</p>
                  <p className="text-xs opacity-70">{address || 'No specific address provided'}</p>
                </div>
              </Popup>
            </Marker>
          </MapContainer>
        ) : (
          <div className="h-full w-full bg-surface-container-low flex flex-col items-center justify-center p-12 text-center">
            <div className="w-16 h-16 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant/40 mb-4">
              <Navigation className="w-8 h-8" />
            </div>
            <h4 className="text-lg font-bold mb-2">Manual Verification Required</h4>
            <p className="text-sm text-on-surface-variant font-medium opacity-60 max-w-xs">
              This report was submitted via text description only. Location data is restricted to provided address:
            </p>
            <div className="mt-4 p-4 bg-white border border-outline-variant/30 rounded-xl font-bold text-primary">
              {address || 'Unknown Location'}
            </div>
          </div>
        )}
      </div>

      {hasCoords && (
        <div className="p-6 bg-surface-container-low border-t border-outline-variant/20 flex flex-wrap gap-6">
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-40 mb-1">Latitude</p>
            <p className="text-sm font-mono font-bold">{lat.toFixed(6)}</p>
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-40 mb-1">Longitude</p>
            <p className="text-sm font-mono font-bold">{lng.toFixed(6)}</p>
          </div>
          <div>
             <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-40 mb-1">Asset Radius</p>
             <p className="text-sm font-bold">100m Verification Circle</p>
          </div>
        </div>
      )}
    </div>
  );
}
