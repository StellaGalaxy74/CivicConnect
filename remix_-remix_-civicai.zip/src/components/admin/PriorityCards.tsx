import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, Clock, CheckCircle2 } from 'lucide-react';
import { cn } from '../../lib/utils';

interface PriorityCardsProps {
  highPriority: number;
  inProgress: number;
  resolvedToday: number;
  activeFilter: string | null;
  onFilterChange: (filter: string | null) => void;
}

export default function PriorityCards({ 
  highPriority, 
  inProgress, 
  resolvedToday, 
  activeFilter, 
  onFilterChange 
}: PriorityCardsProps) {
  const cards = [
    { 
      id: 'high', 
      label: 'Urgent Action', 
      value: highPriority, 
      icon: AlertCircle, 
      color: 'text-error', 
      bg: 'bg-error/5',
      border: 'border-error/20'
    },
    { 
      id: 'active', 
      label: 'In Progress', 
      value: inProgress, 
      icon: Clock, 
      color: 'text-secondary', 
      bg: 'bg-secondary/5',
      border: 'border-secondary/20'
    },
    { 
      id: 'resolved', 
      label: 'Resolved Today', 
      value: resolvedToday, 
      icon: CheckCircle2, 
      color: 'text-primary', 
      bg: 'bg-primary/5',
      border: 'border-primary/20'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
      {cards.map((card, idx) => (
        <motion.button
          key={card.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: idx * 0.1 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onFilterChange(activeFilter === card.id ? null : card.id)}
          className={cn(
            "p-6 rounded-3xl border text-left transition-all relative overflow-hidden group",
            card.bg,
            card.border,
            activeFilter === card.id ? "ring-2 ring-offset-2 ring-primary scale-[1.02] shadow-lg" : "hover:shadow-md"
          )}
        >
          <div className="flex justify-between items-start mb-4">
            <div className={cn("p-2.5 rounded-xl bg-white shadow-sm ring-1 ring-black/5 group-hover:scale-110 transition-transform", card.color)}>
              <card.icon className="w-5 h-5" />
            </div>
            {activeFilter === card.id && (
              <div className="w-2 h-2 rounded-full bg-primary animate-ping" />
            )}
          </div>
          
          <h3 className="text-[10px] font-black uppercase tracking-[0.1em] opacity-40 mb-1">{card.label}</h3>
          <p className="text-3xl font-black tracking-tighter">{card.value}</p>
          
          <div className="absolute -right-4 -bottom-4 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity">
            <card.icon className="w-24 h-24 rotate-12" />
          </div>
        </motion.button>
      ))}
    </div>
  );
}
