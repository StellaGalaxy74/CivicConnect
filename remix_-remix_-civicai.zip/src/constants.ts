import { Issue } from './types';

export const MOCK_ISSUES: Issue[] = [
  {
    id: 'CIV-9402',
    title: 'Street Light Fixed',
    summary: 'A street light was flickering and finally went out.',
    category: 'electricity',
    status: 'RESOLVED',
    priority: 'medium',
    location: '24th Ave & Geary Blvd',
    timestamp: '2 hours ago',
    authorId: 'u1',
    authorName: 'Marcus Sterling',
  },
  {
    id: 'CIV-9398',
    title: 'Pothole on Main St',
    summary: 'Large pothole at the main intersection.',
    category: 'roads',
    status: 'ASSIGNED',
    priority: 'high',
    location: 'Near Central Station',
    timestamp: '5 hours ago',
    authorId: 'u1',
    authorName: 'Marcus Sterling',
  },
  {
    id: 'CIV-882',
    title: 'Broken Water Main',
    summary: 'There is a huge water leak at the intersection. Water is gushing onto the sidewalk.',
    category: 'water',
    status: 'SUBMITTED',
    priority: 'urgent',
    location: '42nd Avenue & Oak Street, North District',
    timestamp: 'Today',
    authorId: 'u2',
    authorName: 'Alice Wong',
  },
  {
    id: 'CIV-8790',
    title: 'Graffiti Removal',
    summary: 'Graffiti on the highway overpass.',
    category: 'sanitation',
    status: 'SUBMITTED',
    priority: 'low',
    location: 'Oak St Underpass',
    timestamp: 'Yesterday',
    authorId: 'u3',
    authorName: 'John Doe',
  }
];

export const MOCK_USER = {
  id: 'u1',
  name: 'Marcus Sterling',
  email: 'm.sterling@civic-net.gov',
  avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBCPvZJs8qCbC-O4MiK2d2PzCC_hH3t4lnGWzszWKnaxa4nrvM_P6ZriEb3gE83DGyP7VCzylKPNj6ZaJ66zMI2oSzuLwVOrr_1cB0lWGonvvEjKAXzBddaBj3N9xD82Y23U8ia24rjM_3q6M8S60X732eQ8QcLgK5um2IrcYnCBRcK4kG10ggXRlnExiE9i9rp8cI0hhBjutaIIuapTgiHbvroXKIgcqgcijqJ3SXoHeTwn17uofZS9Uj0CAAi0uT9oWbRoKQnU5wt',
  role: 'citizen' as const
};

export const MOCK_ADMIN = {
  id: 'a1',
  name: 'Alexander Hamilton',
  email: 'a.hamilton@civic-admin.gov',
  avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuACEzHcx6Mes0HJxyiyodnctrrNlIw6OlxB46ppaQQUJdm0ZQfTjB0eqCjYuV74ZTOgZCVIN-kN7_d554QkDOzNP6Qq3h56ZVL7JH2eKjyiDtqYLwvXyUhg5JBxzl4ZW2icPybhlIDHB-J07aX8BegpGjo4k39Yy3ecjp_r_Q9D4TXOaj8FN3jBxSCLLhrEkpicVShnsaolJH80BmMqH-kTMi7M8cQT5No_8XJy4ZxvA4a-Hvw01qNxdk7fSg7ESRgrVgspuftVTnc2',
  role: 'admin' as const
};
