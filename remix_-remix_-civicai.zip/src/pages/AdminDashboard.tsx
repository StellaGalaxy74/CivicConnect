import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Search, 
  Filter as FilterIcon, 
  Loader2,
  X,
  History
} from 'lucide-react';
import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { issueService } from '../services/issueService';
import { Issue } from '../types';
import { useApp } from '../App';
import DashboardHeader from '../components/admin/DashboardHeader';
import PriorityCards from '../components/admin/PriorityCards';
import ComplaintList from '../components/admin/ComplaintList';

export default function AdminDashboard() {
  const { user } = useApp();
  const navigate = useNavigate();
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    const unsubscribe = issueService.subscribeToIssues((data) => {
      setIssues(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const stats = useMemo(() => {
    const high = issues.filter(i => (i.priority === 'urgent' || i.priority === 'high') && i.status !== 'RESOLVED').length;
    const active = issues.filter(i => i.status === 'ASSIGNED' || i.status === 'IN_PROGRESS').length;
    const resolved = issues.filter(i => i.status === 'RESOLVED').length;
    return { high, active, resolved };
  }, [issues]);

  const filteredIssues = useMemo(() => {
    let result = issues;

    if (activeFilter === 'high') {
      result = result.filter(i => (i.priority === 'urgent' || i.priority === 'high') && i.status !== 'RESOLVED');
    } else if (activeFilter === 'active') {
      result = result.filter(i => i.status === 'ASSIGNED' || i.status === 'IN_PROGRESS');
    } else if (activeFilter === 'resolved') {
      result = result.filter(i => i.status === 'RESOLVED');
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(i => 
        i.title?.toLowerCase().includes(q) || 
        i.summary?.toLowerCase().includes(q) || 
        i.location?.toLowerCase().includes(q) ||
        i.id.toLowerCase().includes(q)
      );
    }

    return result;
  }, [issues, activeFilter, searchQuery]);

  const urgentQueue = useMemo(() => {
    return issues
      .filter(i => (i.priority === 'urgent' || i.priority === 'high') && i.status !== 'RESOLVED')
      .slice(0, 5);
  }, [issues]);

  const recentQueue = useMemo(() => {
    return issues
      .filter(i => !urgentQueue.find(u => u.id === i.id))
      .slice(0, 8);
  }, [issues, urgentQueue]);

  const handleAssign = (id: string) => {
    navigate(`/admin/detail/${id}`);
  };

  const handleResolve = async (id: string) => {
    if (!user) return;
    try {
      await issueService.resolveIssue(id, user.id, user.name);
    } catch (error) {
      console.error('Failed to resolve from dashboard:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-surface-container-low gap-4">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
        <p className="text-[10px] font-black uppercase tracking-widest opacity-40">Synchronizing Operation Center...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-10 pb-32">
      <DashboardHeader />

      {/* Stats Quick Filter Section */}
      <PriorityCards 
        highPriority={stats.high}
        inProgress={stats.active}
        resolvedToday={stats.resolved}
        activeFilter={activeFilter}
        onFilterChange={setActiveFilter}
      />

      <div className="space-y-12">
        {/* Main Triage View or Filtered View */}
        {activeFilter || searchQuery ? (
          <ComplaintList 
            issues={filteredIssues}
            title={activeFilter ? `${activeFilter.charAt(0).toUpperCase() + activeFilter.slice(1)} Feed` : "Search Results"}
            subtitle="Live Filtered Dataset"
            onAssign={handleAssign}
            onResolve={handleResolve}
          />
        ) : (
          <>
            {/* Urgent Focus */}
            <ComplaintList 
              issues={urgentQueue}
              title="Urgent Triage"
              subtitle="Critical actions required now"
              limit={5}
              emptyMessage="No critical escalations pending. System stable."
              onAssign={handleAssign}
              onResolve={handleResolve}
            />

            {/* Recent Activity */}
            <ComplaintList 
              issues={recentQueue}
              title="Activity Feed"
              subtitle="Latest municipal reports"
              limit={8}
              compact={true}
              onAssign={handleAssign}
              onResolve={handleResolve}
            />
          </>
        )}
      </div>

      {/* Quick Action Navigation Bar */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 bg-white/80 backdrop-blur-xl border border-outline-variant/30 rounded-full shadow-2xl p-2 flex items-center gap-2 ring-1 ring-black/5">
        <AnimatePresence>
          {showSearch && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: '240px', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <input 
                autoFocus
                type="text"
                placeholder="Find case..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-12 px-6 bg-surface-container-low border border-outline-variant/20 rounded-full outline-none text-sm font-bold placeholder:opacity-50"
              />
            </motion.div>
          )}
        </AnimatePresence>

        <button 
          onClick={() => setShowSearch(!showSearch)}
          className={cn(
            "h-12 w-12 rounded-full flex items-center justify-center transition-all",
            showSearch ? "bg-primary text-white" : "hover:bg-surface-container text-on-surface-variant"
          )}
        >
          {showSearch ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
        </button>

        <div className="w-px h-6 bg-outline-variant/30" />

        <button 
          onClick={() => setActiveFilter(null)}
          className={cn(
            "h-12 px-6 rounded-full flex items-center gap-2 text-xs font-black uppercase tracking-widest transition-all",
            !activeFilter && !searchQuery ? "bg-primary text-white" : "hover:bg-surface-container text-on-surface-variant"
          )}
        >
          <History className="w-4 h-4" />
          Hub
        </button>

        <button 
          onClick={() => navigate('/report')}
          className="h-12 px-6 bg-on-secondary-container text-white rounded-full text-xs font-black uppercase tracking-widest shadow-lg shadow-on-secondary-container/20 flex items-center gap-2 hover:scale-[1.02] transition-all"
        >
          <Plus className="w-5 h-5" />
          Report
        </button>
      </div>

      {/* Floating System Status */}
      <div className="fixed top-8 right-8 hidden xl:flex flex-col items-end gap-2 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-white/80 backdrop-blur-md rounded-full border border-primary/10 shadow-sm">
          <div className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" />
          <span className="text-[9px] font-black uppercase tracking-tighter opacity-60">System Online</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-white/80 backdrop-blur-md rounded-full border border-primary/10 shadow-sm">
          <span className="text-[9px] font-black uppercase tracking-tighter opacity-60">Response Latency: 1.2s</span>
        </div>
      </div>
    </div>
  );
}
