import { motion } from 'motion/react';
import { ShieldCheck, LogOut, Settings, Award, Users, FileText, ChevronRight, Bell, Lock } from 'lucide-react';
import { useApp } from '../App';
import { useNavigate } from 'react-router-dom';

export default function AdminProfilePage() {
  const { user, signOut } = useApp();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <header className="mb-12">
        <h1 className="text-4xl font-extrabold tracking-tight mb-2">Authority Profile</h1>
        <p className="text-on-surface-variant font-medium text-lg">System administrator settings and governance credentials.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left: Identity Card */}
        <div className="lg:col-span-4 space-y-8">
           <section className="bg-white rounded-3xl border border-outline-variant/30 shadow-sm overflow-hidden flex flex-col items-center p-8 text-center bg-gradient-to-b from-slate-50 to-white">
              <div className="relative mb-6">
                <div className="w-40 h-40 rounded-full border-8 border-surface-container shadow-2xl overflow-hidden">
                  <img src={user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random`} className="w-full h-full object-cover" alt="Admin Avatar" />
                </div>
                <div className="absolute -bottom-2 right-2 bg-secondary text-white p-2.5 rounded-2xl shadow-xl border-4 border-white">
                  <ShieldCheck className="w-6 h-6" />
                </div>
              </div>
              <h2 className="text-2xl font-bold tracking-tight text-primary">{user.name}</h2>
              <p className="text-xs font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-8 mt-1">Super Admin • {user.department || 'Municipal OPS'}</p>
              
              <div className="w-full grid grid-cols-2 gap-4">
                 <div className="bg-white border border-outline-variant/20 p-4 rounded-2xl shadow-sm">
                   <p className="text-[9px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-1">Job ID</p>
                   <p className="text-sm font-display font-black text-on-tertiary-container">{user.jobId || 'OPS-772'}</p>
                 </div>
                 <div className="bg-white border border-outline-variant/20 p-4 rounded-2xl shadow-sm">
                   <p className="text-[9px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-1">Dept</p>
                   <p className="text-sm font-display font-black text-on-tertiary-container">{user.department || 'IT-GOV'}</p>
                 </div>
              </div>
           </section>

           <div className="bg-primary-container text-white p-8 rounded-3xl shadow-xl space-y-6 relative overflow-hidden group">
              <div className="relative z-10">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Award className="w-5 h-5 text-secondary-container" /> System Permissions
                </h3>
                <ul className="space-y-4 text-sm font-medium opacity-80">
                  <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary-container"></span>
                    Full Case Triage & Override
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary-container"></span>
                    Resource Dispatch Authority
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary-container"></span>
                    Historical Reporting Access
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary-container"></span>
                    Identity Verification Mgmt
                  </li>
                </ul>
              </div>
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl group-hover:scale-150 transition-transform"></div>
           </div>
        </div>

        {/* Right: Settings Groups */}
        <div className="lg:col-span-8 space-y-8">
           <section className="bg-white rounded-3xl border border-outline-variant/30 shadow-sm p-8">
              <h3 className="text-xl font-bold tracking-tight mb-8">Admin Dashboard Preferences</h3>
              <div className="space-y-6">
                {[
                  { title: 'Auto-Triage Suggestion', desc: 'Pre-cluster reports based on semantic similarity.', icon: Settings },
                  { title: 'Emergency Broadcast HUD', desc: 'Display global critical alerts in header.', icon: Bell },
                  { title: 'Two-Factor Authentication', desc: 'Secure login with municipal token.', icon: Lock },
                ].map((item, idx) => (
                  <div key={item.title} className="flex items-center justify-between p-6 bg-surface-container-low/30 rounded-2xl border border-outline-variant/10 hover:border-outline-variant/30 transition-all">
                    <div className="flex gap-5">
                      <div className="w-12 h-12 rounded-xl bg-white border border-outline-variant/30 flex items-center justify-center text-on-surface-variant/40">
                        <item.icon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-bold text-lg mb-1">{item.title}</p>
                        <p className="text-xs font-medium text-on-surface-variant/70">{item.desc}</p>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" defaultChecked={idx !== 0} />
                      <div className="w-12 h-6 bg-surface-dim peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-surface-variant after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-on-tertiary-container"></div>
                    </label>
                  </div>
                ))}
              </div>
           </section>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <section className="bg-white border border-outline-variant/30 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                   <Users className="w-5 h-5 text-on-tertiary-container" /> Municipal Contacts
                </h3>
                <div className="space-y-4">
                  {[
                    { name: 'Director of Works', status: 'Online' },
                    { name: 'Public Safety Dispatch', status: 'Busy' },
                  ].map((contact) => (
                    <div key={contact.name} className="flex items-center justify-between p-4 bg-surface-container-low/50 rounded-xl border border-outline-variant/10 group cursor-pointer hover:bg-white transition-all">
                      <span className="text-sm font-bold">{contact.name}</span>
                      <ChevronRight className="w-4 h-4 opacity-10 group-hover:opacity-100 transition-opacity" />
                    </div>
                  ))}
                </div>
              </section>

              <section className="bg-white border border-outline-variant/30 rounded-3xl p-8 shadow-sm">
                 <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                   <FileText className="w-5 h-5 text-secondary" /> Recent Reports Generated
                </h3>
                <div className="space-y-4">
                  {['Q3 Municipal Infrastructure.pdf', 'Sector 7 Audit Logs.csv'].map((file) => (
                    <div key={file} className="flex items-center gap-3 p-4 bg-surface-container-low/50 rounded-xl border border-outline-variant/10 group cursor-pointer hover:bg-white transition-all">
                      <FileText className="w-4 h-4 text-on-surface-variant" />
                      <span className="text-sm font-medium">{file}</span>
                    </div>
                  ))}
                </div>
              </section>
           </div>

           <div className="bg-error-container/20 border border-error-container/30 rounded-3xl p-10 flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-2xl font-bold text-on-error-container mb-1">Administrative Sign Out</h3>
                <p className="text-sm font-medium text-on-error-container/70">Clear all temporary caches and administrative tokens.</p>
              </div>
              <button 
                onClick={handleLogout}
                className="px-10 py-5 bg-white border border-error-container text-error font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-error-container/20 active:scale-95 transition-all shadow-md"
              >
                Immediate Logout
              </button>
           </div>
        </div>
      </div>
    </div>
  );
}
