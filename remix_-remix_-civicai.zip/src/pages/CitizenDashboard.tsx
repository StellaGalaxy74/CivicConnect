import { motion } from 'motion/react';
import { PlusCircle, Search, TrafficCone, Lightbulb, MapPin, ChevronRight, Activity, Clock, CheckCircle2, UserCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useEffect, useState } from 'react';
import { issueService } from '../services/issueService';
import { Issue } from '../types';
import { useApp } from '../App';

export default function CitizenDashboard() {
  const { user } = useApp();
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = issueService.subscribeToIssues((data) => {
      setIssues(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const activityFeed = issues.slice(0, 6);
  const inProgressCount = issues.filter(i => (i.status === 'ASSIGNED' || i.status === 'IN_PROGRESS' || i.status === 'SUBMITTED' || i.status === 'REVIEWED')).length;
  const resolvedCount = issues.filter(i => i.status === 'RESOLVED').length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 md:py-12 text-surface-on">
      <header className="mb-10">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl md:text-4xl font-extrabold tracking-tight"
        >
          Welcome back, {user?.name?.split(' ')[0] || 'Citizen'}
        </motion.h1>
        <p className="text-lg text-on-surface-variant mt-2 font-medium opacity-80">Track your local reports and municipal progress real-time.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Feed */}
        <div className="lg:col-span-8 space-y-8">
          {/* Quick Actions */}
          <section className="bg-white border border-outline-variant/50 rounded-2xl p-8 shadow-sm overflow-hidden relative group">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
              <div>
                <h2 className="text-2xl font-bold tracking-tight">Report an Issue</h2>
                <p className="text-on-surface-variant font-medium mt-1">See something broken? Let us know immediately.</p>
              </div>
              <Link 
                to="/report"
                className="h-14 px-8 bg-primary text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-primary/90 active:scale-95 transition-all shadow-xl"
              >
                <PlusCircle className="w-5 h-5" />
                Submit Report
              </Link>
            </div>
            {/* Visual accent */}
            <div className="absolute top-0 right-0 w-32 h-full bg-secondary-container/5 -skew-x-12 translate-x-8 group-hover:translate-x-4 transition-transform duration-500"></div>
          </section>

          {/* Stats Summary */}
          <section className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white border border-outline-variant/30 rounded-2xl p-8 shadow-sm flex items-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-surface-container flex items-center justify-center text-primary shadow-inner">
                <Clock className="w-8 h-8" />
              </div>
              <div>
                <p className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest opacity-60">Ongoing Impact</p>
                <p className="text-4xl font-display font-extrabold">{inProgressCount.toString().padStart(2, '0')}</p>
              </div>
            </div>
            
            <div className="bg-white border border-outline-variant/30 rounded-2xl p-8 shadow-sm flex items-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-surface-container-highest/50 flex items-center justify-center text-secondary shadow-inner border border-secondary/10">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <p className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest opacity-60">Total Fixed</p>
                <p className="text-4xl font-display font-extrabold">{resolvedCount.toString().padStart(2, '0')}</p>
              </div>
            </div>
          </section>

          {/* Activity Section */}
          <section className="space-y-6">
            <h2 className="text-xl font-bold tracking-tight">Active Reports</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {activityFeed.map((issue) => (
                <Link 
                  to={`/detail/${issue.id}`}
                  key={issue.id}
                  className="bg-white border border-outline-variant/30 p-6 rounded-2xl hover:border-primary/30 transition-all group hover:shadow-md"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className={cn(
                      "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border",
                      issue.status === 'RESOLVED' ? "bg-secondary/10 text-secondary border-secondary/20" :
                      issue.status === 'ASSIGNED' ? "bg-primary/10 text-primary border-primary/20" :
                      "bg-surface-container text-on-surface-variant border-outline-variant/30"
                    )}>
                      {issue.status}
                    </div>
                    <span className="text-[10px] font-black text-on-surface-variant opacity-40">{issue.timestamp}</span>
                  </div>
                  <h4 className="font-extrabold text-lg mb-1 group-hover:text-primary transition-colors">{issue.title || issue.category}</h4>
                  <p className="text-xs text-on-surface-variant font-bold flex items-center gap-1 opacity-70 mb-4">
                    <MapPin className="w-3 h-3" />
                    {issue.location}
                  </p>
                  <div className="flex items-center justify-between pt-4 border-t border-surface-container-low">
                    <div className="flex items-center gap-1.5">
                      <div className="w-6 h-6 rounded-full bg-surface-container flex items-center justify-center">
                        <Activity className="w-3 h-3 text-primary opacity-60" />
                      </div>
                      <span className="text-[9px] font-black uppercase tracking-widest opacity-60">Status Tracking Active</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-primary group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar Activity */}
        <div className="lg:col-span-4">
          <section className="bg-white border border-outline-variant/50 rounded-2xl shadow-xl flex flex-col h-full overflow-hidden">
            <div className="p-8 border-b border-surface-container bg-surface-container-low/30">
              <h2 className="text-xl font-bold tracking-tight flex items-center gap-2">
                <Activity className="w-6 h-6 text-primary" /> Live Pulse
              </h2>
              <p className="text-xs font-bold text-on-surface-variant uppercase tracking-widest mt-2 opacity-60">System-wide updates.</p>
            </div>
            
            <div className="p-8 space-y-8 flex-1">
              {issues.slice(0, 5).map((issue, idx) => (
                <div 
                  key={issue.id} 
                  className="flex gap-5 relative group cursor-pointer"
                >
                  <div className="flex flex-col items-center">
                    <div className={cn(
                      "w-3 h-3 rounded-full mt-2 ring-4 ring-white relative z-10",
                      issue.status === 'RESOLVED' ? "bg-secondary shadow-[0_0_8px_rgba(16,185,129,0.5)]" : 
                      issue.priority === 'urgent' ? "bg-error animate-pulse" : "bg-primary"
                    )} />
                    {idx !== 4 && (
                      <div className="w-px h-full bg-surface-container-high absolute top-4 left-1.5"></div>
                    )}
                  </div>
                  
                  <div className="flex-1 pb-4">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="text-sm font-black leading-tight group-hover:text-primary transition-colors">{issue.title || issue.category}</h4>
                    </div>
                    <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-widest flex items-center gap-1 opacity-70">
                      <MapPin className="w-3 h-3" /> {issue.location.split(',')[0]}
                    </p>
                    <p className="text-[9px] text-outline mt-3 font-black uppercase tracking-tighter opacity-40">{issue.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-auto p-6 border-t border-surface-container bg-surface-container-low/30">
               <div className="flex items-center gap-4 bg-primary rounded-2xl p-5 shadow-inner">
                 <UserCheck className="w-6 h-6 text-white opacity-80" />
                 <div>
                    <p className="text-[9px] font-black uppercase tracking-widest text-white opacity-60">Verified User</p>
                    <p className="text-xs font-bold text-white">Trust Score: 98%</p>
                 </div>
               </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
