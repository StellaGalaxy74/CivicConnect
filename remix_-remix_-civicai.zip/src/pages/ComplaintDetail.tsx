import { 
  ArrowLeft, 
  Share2, 
  MapPin, 
  Clock, 
  Phone, 
  Mail, 
  Droplets, 
  CheckCircle2, 
  ArrowRight,
  Maximize2,
  AlertTriangle,
  History,
  ShieldCheck,
  User as UserIcon,
  Truck,
  Play,
  Camera,
  Navigation,
  ExternalLink,
  Loader2
} from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { issueService } from '../services/issueService';
import { Issue, IssueStatus, TimelineEvent } from '../types';
import { useApp } from '../App';
import StatusActions from '../components/StatusActions';
import DispatchPanel from '../components/DispatchPanel';
import ImageGallery from '../components/admin/ImageGallery';
import MapView from '../components/admin/MapView';

export default function ComplaintDetailPage() {
  const { id } = useParams();
  const { role, user } = useApp();
  const navigate = useNavigate();
  const [issue, setIssue] = useState<Issue | null>(null);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (id) {
      setLoading(true);
      issueService.getIssue(id).then(data => {
        setIssue(data);
        setLoading(false);
      });

      const unsubscribeTimeline = issueService.subscribeToTimeline(id, (events) => {
        setTimeline(events);
      });

      return () => unsubscribeTimeline();
    }
  }, [id]);

  const handleUpdateStatus = async (newStatus: IssueStatus, message: string) => {
    if (!issue || !id || !user) return;
    setUpdating(true);
    try {
      await issueService.updateIssueStatus(id, newStatus, message, user.id, user.name);
      setIssue({ ...issue, status: newStatus });
    } catch (error) {
      console.error('Failed to update status:', error);
    } finally {
      setUpdating(false);
    }
  };

  const handleDispatch = async (team: string) => {
    if (!issue || !id || !user) return;
    setUpdating(true);
    try {
      await issueService.dispatchTeam(id, team, user.id, user.name);
      setIssue({ ...issue, status: 'ASSIGNED', assignedTeam: team });
    } catch (error) {
      console.error('Failed to dispatch team:', error);
    } finally {
      setUpdating(false);
    }
  };

  const handlePriorityUpdate = async (priority: any) => {
    if (!id || !user) return;
    setUpdating(true);
    try {
      await issueService.updatePriority(id, priority, user.id, user.name || 'Admin');
      setIssue(prev => prev ? { ...prev, priority } : null);
    } catch (error) {
      console.error(error);
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-surface-container-low">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
        <p className="text-[10px] font-black uppercase tracking-widest opacity-40">Decrypting Case Data...</p>
      </div>
    );
  }

  if (!issue) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
        <AlertTriangle className="w-16 h-16 text-error mb-4" />
        <h2 className="text-2xl font-bold mb-2">Complaint Not Found</h2>
        <p className="text-on-surface-variant mb-6">The ID you're looking for doesn't exist or has been archived.</p>
        <button onClick={() => navigate(-1)} className="px-8 py-3 bg-primary text-white rounded-xl font-bold">Return to Hub</button>
      </div>
    );
  }

  const statusColors: Record<IssueStatus, string> = {
    SUBMITTED: 'bg-surface-container text-on-surface-variant border-outline-variant/30',
    REVIEWED: 'bg-on-tertiary-container/10 text-on-tertiary-container border-on-tertiary-container/20',
    ASSIGNED: 'bg-primary/10 text-primary border-primary/20',
    IN_PROGRESS: 'bg-secondary/10 text-secondary border-secondary/20',
    RESOLVED: 'bg-secondary text-white border-secondary'
  };

  const isAdmin = role === 'admin';

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div className="space-y-4">
          <button 
            onClick={() => navigate(-1)}
            className="group flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-on-surface-variant hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center gap-3">
             <span className={cn(
              "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border shadow-sm",
              statusColors[issue.status]
            )}>
              {issue.status}
            </span>
            <span className="text-[12px] font-bold text-on-surface-variant/40">ID: {issue.id}</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-primary font-display leading-[1.1]">
            {issue.title || `${issue.category.charAt(0).toUpperCase() + issue.category.slice(1)} Issue`}
          </h1>
          
          <div className="flex flex-wrap items-center gap-6 text-on-surface-variant font-bold text-sm">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              {issue.location}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-secondary" />
              {issue.timestamp}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="h-12 w-12 bg-white border border-outline-variant/50 rounded-xl flex items-center justify-center hover:bg-surface-container transition-all shadow-sm">
            <Share2 className="w-5 h-5 text-on-surface-variant" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Complaint Intelligence */}
        <div className="lg:col-span-8 space-y-8">
          {/* Admin Command Center */}
          {isAdmin && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border-2 border-primary/20 rounded-3xl p-8 shadow-xl"
            >
              <div className="flex items-center gap-3 mb-6">
                <ShieldCheck className="w-6 h-6 text-primary" />
                <h3 className="text-xl font-black tracking-tight text-primary uppercase">Admin Command Center</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Priority Triage */}
                <div className="space-y-4">
                  <h4 className="text-sm font-black uppercase tracking-widest text-on-surface-variant/60">Priority Triage</h4>
                  <div className="flex flex-wrap gap-2">
                    {['low', 'medium', 'high', 'urgent'].map((p) => (
                      <button
                        key={p}
                        onClick={() => handlePriorityUpdate(p as any)}
                        disabled={updating}
                        className={cn(
                          "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border-2",
                          issue.priority === p 
                            ? "bg-primary text-white border-primary shadow-lg scale-105" 
                            : "bg-white text-on-surface-variant border-outline-variant/30 hover:border-primary/50"
                        )}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Dispatch / Status Actions */}
                <div className="space-y-4">
                  <h4 className="text-sm font-black uppercase tracking-widest text-on-surface-variant/60">Status Management</h4>
                  <div className="flex items-center gap-3">
                    <StatusActions 
                      currentStatus={issue.status} 
                      onUpdateStatus={handleUpdateStatus} 
                      isLoading={updating} 
                    />
                  </div>
                </div>
              </div>

              {issue.status === 'REVIEWED' && (
                <div className="mt-8 pt-8 border-t border-outline-variant/20">
                  <DispatchPanel 
                    category={issue.category} 
                    onDispatch={handleDispatch} 
                    isLoading={updating} 
                  />
                </div>
              )}
            </motion.div>
          )}

          {/* AI Insights Card */}
          <section className="bg-primary/5 border border-primary/10 rounded-3xl p-8 relative overflow-hidden group">
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-8">
                <div className="p-2 bg-primary/10 rounded-xl text-primary ring-4 ring-primary/5">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold tracking-tight text-primary">Intelligence Summary</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div className="bg-white/40 backdrop-blur-md p-5 rounded-2xl border border-white/60 shadow-sm">
                  <p className="text-[9px] font-black text-primary uppercase tracking-widest mb-2 opacity-50">Priority Level</p>
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      issue.priority === 'urgent' ? "bg-error animate-pulse" : 
                      issue.priority === 'high' ? "bg-error/70" : "bg-secondary"
                    )} />
                    <span className="font-black text-lg text-primary uppercase tracking-tight">{issue.priority}</span>
                  </div>
                </div>
                <div className="bg-white/40 backdrop-blur-md p-5 rounded-2xl border border-white/60 shadow-sm">
                  <p className="text-[9px] font-black text-primary uppercase tracking-widest mb-2 opacity-50">Category</p>
                  <span className="font-black text-lg text-primary uppercase tracking-tight">{issue.category}</span>
                </div>
                <div className="bg-white/40 backdrop-blur-md p-5 rounded-2xl border border-white/60 shadow-sm">
                  <p className="text-[9px] font-black text-primary uppercase tracking-widest mb-2 opacity-50">Reporter</p>
                  <span className="font-black text-sm text-primary truncate block">{issue.authorName}</span>
                </div>
                <div className="bg-white/40 backdrop-blur-md p-5 rounded-2xl border border-white/60 shadow-sm">
                  <p className="text-[9px] font-black text-primary uppercase tracking-widest mb-2 opacity-50">Occurrence</p>
                  <span className="font-black text-xs text-primary">{issue.occurrenceDate} @ {issue.occurrenceTime}</span>
                </div>
              </div>

              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white shadow-sm ring-1 ring-primary/5">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-primary mb-3 opacity-60">Citizen Observation</h4>
                <p className="text-lg font-medium text-primary/80 leading-relaxed italic">
                  "{issue.summary}"
                </p>
              </div>
            </div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-[100px] -mr-48 -mt-48 transition-transform duration-1000 group-hover:scale-125"></div>
          </section>

          {/* Visual Proof */}
          <section className="bg-white p-8 rounded-3xl border border-outline-variant/30 shadow-sm">
            <ImageGallery images={issue.images || []} />
          </section>

          {/* Location Visualization */}
          <section>
            <MapView 
              lat={issue.latitude} 
              lng={issue.longitude} 
              address={issue.location}
              category={issue.category}
            />
          </section>

          {/* Assigned Team Section */}
          {issue.assignedTeam && (
            <motion.section 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-secondary/5 p-8 rounded-3xl border border-secondary/20 shadow-sm relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-bold tracking-tight text-secondary-container">Deployment Status</h3>
                <div className="px-4 py-1.5 bg-secondary text-white rounded-full text-[10px] font-black uppercase tracking-widest">
                  Active Response
                </div>
              </div>
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="w-24 h-24 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary shadow-inner flex-shrink-0 animate-pulse">
                  <Truck className="w-12 h-12" />
                </div>
                <div className="flex-1 space-y-6">
                  <div>
                    <h4 className="text-2xl font-black text-secondary-container mb-1">{issue.assignedTeam}</h4>
                    <p className="text-secondary font-bold text-sm opacity-70">Assigned Response Unit • Dispatch ID: DE-{issue.id.slice(-4).toUpperCase()}</p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex items-center gap-4 p-4 bg-white/60 backdrop-blur-sm rounded-2xl border border-secondary/10 shadow-sm font-bold">
                      <Phone className="w-5 h-5 text-secondary" />
                      <div>
                        <p className="text-[9px] uppercase tracking-widest text-secondary opacity-50">Team Comm</p>
                        <p className="text-sm text-secondary-container">+1 (555) 012-{issue.id.slice(-4)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 p-4 bg-white/60 backdrop-blur-sm rounded-2xl border border-secondary/10 shadow-sm font-bold">
                      <ShieldCheck className="w-5 h-5 text-secondary" />
                      <div>
                        <p className="text-[9px] uppercase tracking-widest text-secondary opacity-50">Protocol</p>
                        <p className="text-sm text-secondary-container">Standard Response</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.section>
          )}
        </div>

        {/* Right Column: Tracking & Timeline */}
        <aside className="lg:col-span-4 space-y-8">
          <section className="bg-white p-8 rounded-3xl border border-outline-variant/30 shadow-sm">
             <div className="flex items-center justify-between mb-10">
               <div>
                <h3 className="text-xl font-bold tracking-tight">Lifecycle</h3>
                <p className="text-[10px] font-black uppercase tracking-widest opacity-40">Chain of Custody</p>
               </div>
               <History className="w-6 h-6 text-on-surface-variant opacity-20" />
             </div>
            
            <div className="space-y-8 relative">
              <div className="absolute left-[19px] top-6 bottom-6 w-0.5 bg-surface-container"></div>
              {timeline.map((event, idx) => {
                const isLast = idx === timeline.length - 1;
                
                return (
                  <motion.div 
                    key={event.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="relative flex items-start gap-4"
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center z-10 transition-all shadow-lg border-4 border-white",
                      isLast ? "bg-primary text-white scale-110" : "bg-surface-container-high text-on-surface-variant"
                    )}>
                      {event.status === 'RESOLVED' ? <CheckCircle2 className="w-4 h-4" /> : 
                       event.status === 'ASSIGNED' ? <Truck className="w-4 h-4" /> :
                       event.status === 'IN_PROGRESS' ? <Play className="w-4 h-4" /> :
                       <Clock className="w-4 h-4" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className={cn("font-black text-sm uppercase tracking-tight", isLast ? "text-primary" : "text-on-surface-variant")}>
                          {event.status}
                        </h4>
                      </div>
                      <p className="text-[10px] font-bold text-on-surface-variant/40 mb-2">
                        {event.timestamp?.toDate ? event.timestamp.toDate().toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Processing...'}
                      </p>
                      <div className="bg-surface-container-low/50 p-3 rounded-xl border border-outline-variant/10">
                        <p className="text-[11px] text-on-surface-variant font-bold leading-relaxed">
                          {event.message}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 mt-2 opacity-50 px-1">
                        <ShieldCheck className="w-3 h-3 text-primary" />
                        <span className="text-[9px] font-black uppercase tracking-tighter">Verified: {event.updatedByName}</span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
              {timeline.length === 0 && (
                <div className="text-center py-10 opacity-40">
                  <Loader2 className="w-6 h-6 mx-auto animate-spin mb-2" />
                  <p className="text-[10px] font-black uppercase tracking-widest">Syncing Audit Log...</p>
                </div>
              )}
            </div>
          </section>

          {/* Quick Metrics */}
          <section className="bg-surface-container p-8 rounded-3xl border border-outline-variant/30 space-y-6">
            <h3 className="text-sm font-black uppercase tracking-widest text-primary opacity-60">System Metrics</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-on-surface-variant">Avg. Response Time</span>
                <span className="text-xs font-black text-primary">14.2m</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-on-surface-variant">SLA Compliance</span>
                <span className="text-xs font-black text-secondary">98.4%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-on-surface-variant">Citizen Satisfaction</span>
                <div className="flex gap-0.5 text-secondary">
                  {[1,2,3,4,5].map(i => <div key={i} className="w-1.5 h-1.5 rounded-full bg-current"></div>)}
                </div>
              </div>
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

