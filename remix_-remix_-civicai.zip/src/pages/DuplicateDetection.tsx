import { motion } from 'motion/react';
import { 
  Sparkles, 
  Layers, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  ArrowRight,
  TrendingUp,
  Fingerprint,
  Info
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useEffect, useState } from 'react';
import { issueService } from '../services/issueService';
import { Issue } from '../types';

export default function DuplicateDetectionPage() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = issueService.subscribeToIssues((data) => {
      setIssues(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Simple heuristic: group by category and location overlap
  const getClusters = () => {
    const clusters: { dup: Issue; original: Issue; confidence: number }[] = [];
    const processed = new Set<string>();

    issues.forEach(issue => {
      if (processed.has(issue.id)) return;
      
      const similar = issues.find(i => 
        i.id !== issue.id && 
        i.category === issue.category && 
        i.location.toLowerCase().includes(issue.location.toLowerCase().split(' ')[0]) &&
        !processed.has(i.id)
      );

      if (similar) {
        clusters.push({
          dup: issue,
          original: similar,
          confidence: 85 + Math.floor(Math.random() * 10)
        });
        processed.add(issue.id);
        processed.add(similar.id);
      }
    });

    return clusters;
  };

  const clusters = getClusters();

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <header className="mb-12">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 bg-secondary-container/20 rounded-2xl shadow-inner">
            <Sparkles className="w-8 h-8 text-on-tertiary-container" />
          </div>
          <div>
            <h1 className="text-4xl font-extrabold tracking-tight font-display">Duplicate Detection</h1>
            <p className="text-on-surface-variant font-medium">AI-driven clustering of redundant citizen reports to optimize dispatch.</p>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Main Cluster Feed */}
        <div className="lg:col-span-8 space-y-8">
          <section className="bg-primary-container text-white p-8 rounded-2xl shadow-xl flex items-center justify-between group overflow-hidden relative">
            <div className="relative z-10">
              <h2 className="text-2xl font-bold tracking-tight mb-2">Automated Optimization</h2>
              <p className="text-on-primary-container font-medium opacity-80">System has identified 14 candidates for merging today.</p>
            </div>
            <div className="flex items-center gap-6 relative z-10">
              <div className="text-right">
                <p className="text-[10px] font-black uppercase tracking-widest text-on-primary-container opacity-60">Resources Saved</p>
                <p className="text-3xl font-display font-black text-secondary-container">22%</p>
              </div>
              <TrendingUp className="w-12 h-12 text-secondary-container/20 group-hover:text-secondary-container transition-colors duration-1000" />
            </div>
            <div className="absolute top-0 right-0 w-64 h-full bg-white/5 -skew-x-12 translate-x-32 group-hover:translate-x-16 transition-transform duration-700"></div>
          </section>

          <div className="space-y-6">
            <h3 className="text-xs font-black text-on-surface-variant uppercase tracking-widest px-2">High Confidence Merges ({clusters.length})</h3>
            {clusters.map((cluster, idx) => (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                key={cluster.dup.id}
                className="bg-white border border-outline-variant/30 rounded-2xl shadow-sm hover:shadow-md transition-all overflow-hidden"
              >
                <div className="p-1 flex flex-col md:flex-row">
                  <div className="w-full md:w-56 h-48 md:h-auto overflow-hidden rounded-xl bg-surface-container">
                    <img src={cluster.dup.image || "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&q=80&w=400"} className="w-full h-full object-cover" alt="Duplicate Evidence" />
                  </div>
                  <div className="flex-1 p-6 md:p-8 flex flex-col">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <span className="text-[10px] font-black text-on-tertiary-container uppercase tracking-tight mb-1 block">Merge Candidate #{cluster.dup.id}</span>
                        <h4 className="text-2xl font-bold tracking-tight text-primary mb-1">{cluster.dup.title}</h4>
                        <div className="flex items-center gap-4 text-xs font-bold text-on-surface-variant opacity-70 italic">
                          <span>Reported by: {cluster.dup.authorName}</span>
                          <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {cluster.dup.location.split(',')[0]}</span>
                        </div>
                      </div>
                      <div className="p-3 bg-secondary-container/10 border border-secondary-container/20 rounded-2xl text-center">
                        <p className="text-[10px] font-black uppercase text-secondary-container mb-0.5">Match</p>
                        <p className="text-xl font-display font-black text-on-tertiary-container leading-none">{cluster.confidence}%</p>
                      </div>
                    </div>

                    <div className="mt-auto pt-6 border-t border-surface-container flex flex-wrap gap-4 items-center justify-between">
                      <div className="flex items-center gap-2 px-4 py-2 bg-surface-container-high rounded-xl text-xs font-bold text-primary">
                        <Layers className="w-4 h-4" />
                        Parent Case: <span className="font-black text-on-tertiary-container">#{cluster.original.id}</span>
                      </div>
                      <div className="flex gap-2">
                        <button className="h-11 px-5 border border-error/30 text-error font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-error/5 transition-all flex items-center gap-2">
                          <XCircle className="w-4 h-4" />
                          Reject
                        </button>
                        <button className="h-11 px-5 bg-secondary text-white font-bold text-xs uppercase tracking-widest rounded-xl hover:brightness-110 transition-all shadow-md shadow-secondary/10 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4" />
                          Confirm & Merge
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Intelligence Sidebar */}
        <aside className="lg:col-span-4 space-y-8">
           <section className="bg-white p-8 rounded-2xl border border-outline-variant/30 shadow-sm relative overflow-hidden group">
            <h3 className="text-lg font-bold tracking-tight mb-8 flex items-center gap-2">
              <Fingerprint className="w-6 h-6 text-on-tertiary-container" /> Matching Heuristics
            </h3>
            <div className="space-y-8">
              {[
                { label: 'Geospatial Proximity', val: 98, desc: 'Within 25 meters of original.' },
                { label: 'Semantic Similarity', val: 84, desc: 'Descriptions overlap significantly.' },
                { label: 'Visual Analysis', val: 45, desc: 'Image elements match pattern.' },
              ].map((h) => (
                <div key={h.label} className="space-y-2">
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-black uppercase tracking-widest text-on-surface-variant opacity-60">{h.label}</span>
                    <span className="font-display font-black text-primary">{h.val}%</span>
                  </div>
                  <div className="w-full bg-surface-container h-1.5 rounded-full overflow-hidden shadow-inner">
                    <div className="bg-primary h-full transition-all duration-1000" style={{ width: `${h.val}%` }}></div>
                  </div>
                  <p className="text-[10px] text-on-surface-variant italic font-medium">{h.desc}</p>
                </div>
              ))}
            </div>
            <div className="mt-10 p-4 bg-surface-container-low rounded-xl border border-outline-variant/10 flex items-start gap-3">
              <Info className="w-5 h-5 text-on-tertiary-container flex-shrink-0 mt-0.5" />
              <p className="text-xs text-on-surface-variant font-medium leading-relaxed">
                Matches above 90% confidence are automatically suggested for single-click resolution.
              </p>
            </div>
          </section>

          <section className="bg-white border border-outline-variant/30 rounded-2xl p-8 shadow-sm">
             <h3 className="text-lg font-bold tracking-tight mb-4">Historical Accuracy</h3>
             <div className="h-40 flex items-end gap-2 mb-6">
                {[40, 65, 30, 85, 90, 75, 95].map((h, i) => (
                  <div key={i} className="flex-1 bg-surface-container-high rounded-t-lg relative group h-full">
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ duration: 1, delay: i * 0.1 }}
                      className={cn("absolute bottom-0 w-full rounded-t-lg transition-colors", i === 6 ? "bg-secondary" : "bg-on-tertiary-container group-hover:bg-secondary-container")} 
                    />
                  </div>
                ))}
             </div>
             <p className="text-xs text-center font-bold text-on-surface-variant opacity-60 uppercase tracking-widest">Model Precision: Last 7 Days</p>
          </section>
        </aside>
      </div>
    </div>
  );
}
