import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Mail, ArrowLeft, RefreshCw } from 'lucide-react';
import { useState } from 'react';

export default function ForgotPasswordPage() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-6 bg-surface">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <div className="bg-white border border-outline-variant/50 rounded-3xl p-10 shadow-xl relative overflow-hidden group">
          <Link 
            to="/login"
            className="flex items-center gap-2 text-on-surface-variant hover:text-primary transition-colors font-black text-[10px] uppercase tracking-widest mb-10 group/back"
          >
            <ArrowLeft className="w-4 h-4 group-hover/back:-translate-x-1 transition-transform" />
            Back to Login
          </Link>

          {!submitted ? (
            <>
              <div className="mb-10">
                <h1 className="text-3xl font-extrabold tracking-tight mb-2 font-display">Account Recovery</h1>
                <p className="text-on-surface-variant font-medium">Enter your verified email to receive an identity reset link.</p>
              </div>

              <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Email Address</label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                    <input 
                      type="email" 
                      required
                      placeholder="name@example.com"
                      className="w-full pl-12 pr-4 h-14 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full h-14 bg-primary text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-xl"
                >
                  Send Recovery Link
                  <RefreshCw className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="text-center py-10">
              <div className="w-20 h-20 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mx-auto mb-8 shadow-inner ring-8 ring-secondary/5">
                <Mail className="w-10 h-10" />
              </div>
              <h1 className="text-3xl font-extrabold tracking-tight mb-4 font-display">Email Sent</h1>
              <p className="text-on-surface-variant font-medium mb-10 px-4">
                If an account exists for that email, you will receive a reset link shortly. Please check your spam folder if it doesn't appear.
              </p>
              <button 
                onClick={() => setSubmitted(false)}
                className="text-on-tertiary-container font-black text-xs uppercase tracking-widest hover:underline"
              >
                Try a different email
              </button>
            </div>
          )}

          <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-primary/5 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000"></div>
        </div>
      </motion.div>
    </div>
  );
}
