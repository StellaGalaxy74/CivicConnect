import { motion } from 'motion/react';
import { 
  Map as MapIcon, 
  Search, 
  Layers, 
  Navigation, 
  Plus, 
  Minus, 
  Filter, 
  Maximize2,
  TriangleAlert,
  Droplets,
  Zap,
  Trash2,
  Activity,
  ArrowRight
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useEffect, useState } from 'react';
import { issueService } from '../services/issueService';
import { Issue } from '../types';

export default function HotspotMapPage() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [liveAlert, setLiveAlert] = useState<Issue | null>(null);

  useEffect(() => {
    const unsubscribe = issueService.subscribeToIssues((data) => {
      setIssues(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (isTracking && navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition((position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });

        // Live detector: Find issues near current location (simple distance check)
        const nearby = issues.find(issue => {
          if (!issue.latitude || !issue.longitude) return false;
          const dist = Math.sqrt(
            Math.pow(issue.latitude - latitude, 2) + 
            Math.pow(issue.longitude - longitude, 2)
          );
          return dist < 0.01; // Approx 1km
        });
        
        if (nearby && nearby.status !== 'resolved') {
          setLiveAlert(nearby);
        } else {
          setLiveAlert(null);
        }
      });
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [isTracking, issues]);

  const toggleTracking = () => {
    setIsTracking(!isTracking);
    if (!isTracking && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setUserLocation({ lat: position.coords.latitude, lng: position.coords.longitude });
      });
    }
  };

  const zones = [
    { name: 'North District', value: issues.filter(i => i.location.includes('North')).length, color: 'bg-error', icon: TriangleAlert },
    { name: 'Downtown Center', value: issues.filter(i => i.location.includes('Downtown')).length, color: 'bg-on-tertiary-container', icon: Activity },
    { name: 'East Riverside', value: issues.filter(i => i.location.includes('East')).length, color: 'bg-secondary', icon: Droplets },
  ];

  const totalCritical = issues.filter(i => i.status === 'critical').length;
  const totalActive = issues.filter(i => i.status !== 'resolved').length;

  return (
    <div className="h-[calc(100vh-64px)] w-full flex flex-col md:flex-row overflow-hidden bg-surface-container-low">
      {/* Sidebar Controls */}
      <aside className="w-full md:w-80 h-full bg-white border-r border-outline-variant/30 flex flex-col z-20">
        <div className="p-6 border-b border-surface-container">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-secondary-container/20 rounded-xl">
              <MapIcon className="w-6 h-6 text-on-tertiary-container" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Geospatial Intelligence</h1>
          </div>

          <div className="relative group mb-4">
             <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant/40 w-4 h-4 group-focus-within:text-primary transition-colors" />
             <input 
              type="text" 
              placeholder="Search by neighborhood..."
              className="w-full pl-10 pr-4 h-11 bg-surface-container-low border border-outline-variant/30 rounded-xl focus:ring-2 focus:ring-primary/10 transition-all font-medium text-sm outline-none"
             />
          </div>

          <div className="flex gap-2">
             <button className="flex-1 flex items-center justify-center gap-2 h-10 px-4 bg-surface-container-high rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-surface-container-highest transition-all">
              <Filter className="w-3.5 h-3.5" />
              Legend
             </button>
             <button className="flex-1 flex items-center justify-center gap-2 h-10 px-4 bg-primary text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:opacity-90 transition-all shadow-sm">
              <Layers className="w-3.5 h-3.5" />
              Layers
             </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8 scrollbar-hide">
          <section>
            <h2 className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest mb-6">Active Reporting Density</h2>
            <div className="space-y-4">
              {zones.map((zone) => (
                <div key={zone.name} className="flex items-center justify-between p-4 bg-surface-container-low/50 rounded-2xl border border-outline-variant/10 shadow-sm hover:shadow-md transition-all cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-sm", zone.color)}>
                      <zone.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-bold text-sm text-primary">{zone.name}</p>
                      <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/60">{zone.value} Reports</p>
                    </div>
                  </div>
                  <Navigation className="w-4 h-4 text-on-surface-variant/30 hover:text-primary transition-colors" />
                </div>
              ))}
            </div>
          </section>

          {liveAlert && (
            <motion.section 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-error text-white p-6 rounded-2xl shadow-xl relative overflow-hidden group border-2 border-error-container"
            >
              <div className="flex items-center gap-2 mb-2 relative z-10">
                <TriangleAlert className="w-5 h-5 animate-pulse" />
                <h3 className="text-lg font-bold tracking-tight">Proximity Alert!</h3>
              </div>
              <p className="text-xs font-medium text-white/90 mb-4 relative z-10">
                A critical issue ({liveAlert.title}) was detected near your current location.
              </p>
              <div className="flex gap-2 relative z-10">
                <button className="flex-1 bg-white text-error py-2 rounded-xl text-[10px] font-black uppercase tracking-widest">View Details</button>
                <button onClick={() => setLiveAlert(null)} className="flex-1 bg-error-container/20 text-white py-2 rounded-xl text-[10px] font-black uppercase tracking-widest">Dismiss</button>
              </div>
            </motion.section>
          )}

          <section className="bg-primary-container text-white p-6 rounded-2xl shadow-xl relative overflow-hidden group">
            <h3 className="text-lg font-bold tracking-tight mb-2 relative z-10">Anomalies Detected</h3>
            <p className="text-xs font-medium text-on-primary-container/80 mb-6 relative z-10">
              {totalCritical} critical incidents detected across all districts.
            </p>
            <button className="bg-white text-primary px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:brightness-110 active:scale-95 transition-all relative z-10">Deploy Response</button>
            <div className="absolute -bottom-8 -right-8 w-24 h-24 bg-secondary-container/10 rounded-full blur-2xl group-hover:scale-150 transition-transform"></div>
          </section>
        </div>
      </aside>

      {/* Main Map Canvas */}
      <div className="flex-1 relative bg-surface-container overflow-hidden">
        <img 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuCNPpzKG0icsHc_GUN-6rywflj7DyXBN7iti2m0gAspZlgS341qQuRnsGRI7Nt5C2kc8diPAVKtgEsFTZeBNBv4xGBU1dUg_VXYK0Dc-xdNAY_BMEqe5K7hXC7CLvVu5oNKlBIeFgj9Ho2avzndvKtZPSeomqUlxE5I56nkeefJcrSktPQEBvg5S103k1tJBVj60fELM2BwtEM5cc0szKG4jh_foqBxQ1KTzVAq6xfzLALeIkr5MQSH8Sc4V9XlSqhasKLRF4quF-8M" 
          className="w-full h-full object-cover grayscale opacity-60" 
          alt="Base Map"
        />

        {/* Heatmap/Hotspot Overlay Mockups */}
        <div className="absolute inset-0">
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: Math.min(0.1 + totalActive/50, 0.4) }}
            transition={{ duration: 2, repeat: Infinity, repeatType: 'reverse' }}
            className="absolute top-1/4 left-1/3 w-96 h-96 bg-error rounded-full blur-[100px]"
          />
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: Math.min(0.05 + totalCritical/20, 0.3) }}
            transition={{ duration: 2.5, repeat: Infinity, repeatType: 'reverse', delay: 0.5 }}
            className="absolute top-1/2 right-1/4 w-80 h-80 bg-on-tertiary-container rounded-full blur-[80px]"
          />
          {userLocation && isTracking && (
             <div className="absolute" style={{ top: '45%', left: '42%' }}>
                <motion.div 
                  initial={{ scale: 0 }} 
                  animate={{ scale: 1 }}
                  className="relative"
                >
                  <div className="absolute inset-0 bg-primary/30 rounded-full animate-ping"></div>
                  <div className="relative z-10 w-8 h-8 bg-primary rounded-full shadow-2xl flex items-center justify-center border-4 border-white text-white">
                    <Navigation className="w-4 h-4 fill-current rotate-45" />
                  </div>
                </motion.div>
                <div className="absolute top-10 whitespace-nowrap bg-white/90 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-primary shadow-sm border border-outline-variant/30">You are here</div>
             </div>
          )}
          {issues.filter(i => i.status === 'critical').slice(0, 5).map((issue, idx) => (
             <div key={issue.id} className="absolute" style={{ top: `${20 + idx * 15}%`, left: `${30 + idx * 10}%` }}>
              <motion.div 
                initial={{ scale: 0 }} 
                animate={{ scale: 1 }}
                className="relative"
              >
                <div className="absolute inset-0 bg-error/30 rounded-full animate-ping"></div>
                <div className="relative z-10 w-10 h-10 bg-white rounded-full shadow-2xl flex items-center justify-center border-2 border-error text-error">
                  <TriangleAlert className="w-5 h-5 fill-current" />
                </div>
              </motion.div>
            </div>
          ))}
        </div>

        {/* Map UI Floating Controls */}
        <div className="absolute right-6 top-6 flex flex-col gap-3">
          <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-xl flex flex-col border border-outline-variant/30 overflow-hidden">
            <button className="p-3.5 hover:bg-surface-container transition-colors border-b border-surface-container text-on-surface-variant/60 hover:text-primary"><Plus className="w-5 h-5" /></button>
            <button className="p-3.5 hover:bg-surface-container transition-colors text-on-surface-variant/60 hover:text-primary"><Minus className="w-5 h-5" /></button>
          </div>
          <button 
            onClick={toggleTracking}
            className={cn(
              "p-3.5 rounded-2xl shadow-xl border transition-all",
              isTracking 
                ? "bg-primary text-white border-primary" 
                : "bg-white/90 backdrop-blur-md text-on-surface-variant/60 hover:text-primary border-outline-variant/30"
            )}
          >
            <Navigation className={cn("w-5 h-5", isTracking && "fill-current")} />
          </button>
        </div>

        <div className="absolute left-6 bottom-6 right-6 md:left-auto md:w-96 bg-white/95 backdrop-blur-md p-6 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-outline-variant/30">
           <div className="flex justify-between items-start mb-6">
             <div>
               <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant/60 mb-1">City Wide Insight</p>
               <h4 className="text-xl font-bold tracking-tight text-primary">Overview Monitor</h4>
             </div>
             <button className="p-2.5 rounded-xl bg-surface-container hover:bg-surface-container-high transition-colors"><Maximize2 className="w-4 h-4" /></button>
           </div>
           
           <div className="grid grid-cols-2 gap-4">
              <div className="bg-surface-container-low/50 p-4 rounded-2xl border border-outline-variant/10 text-center">
                 <p className="text-[9px] font-black uppercase text-on-surface-variant/60 tracking-wider mb-0.5">Active</p>
                 <p className="text-2xl font-display font-black text-on-surface">{totalActive}</p>
              </div>
              <div className="bg-surface-container-low/50 p-4 rounded-2xl border border-outline-variant/10 text-center">
                 <p className="text-[9px] font-black uppercase text-on-surface-variant/60 tracking-wider mb-0.5">Critical</p>
                 <p className="text-2xl font-display font-black text-error">{totalCritical}</p>
              </div>
           </div>

           <button className="w-full mt-6 py-4 bg-primary text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:opacity-90 active:scale-[0.98] transition-all shadow-lg flex items-center justify-center gap-2">
             Dispatch Rapid Response UNIT
             <ArrowRight className="w-4 h-4" />
           </button>
        </div>

        <div className="absolute top-6 left-6 hidden lg:flex flex-col gap-2 p-2 bg-white/40 backdrop-blur-xl border border-white/50 rounded-2xl shadow-xl">
           <button className="w-10 h-10 rounded-xl bg-white text-secondary flex items-center justify-center shadow-md"><Zap className="w-5 h-5 fill-current" /></button>
           <button className="w-10 h-10 rounded-xl bg-white/30 text-white flex items-center justify-center hover:bg-white/50 transition-all"><Droplets className="w-5 h-5" /></button>
           <button className="w-10 h-10 rounded-xl bg-white/30 text-white flex items-center justify-center hover:bg-white/50 transition-all"><Trash2 className="w-5 h-5" /></button>
        </div>
      </div>
    </div>
  );
}
