import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Mail, Lock, ArrowRight, Github, Chrome } from 'lucide-react';
import { useState } from 'react';
import React from 'react';
import { signInWithGoogle, auth } from '../lib/firebase';
import { userService } from '../services/userService';
import { signInWithEmailAndPassword } from 'firebase/auth';

export default function LoginPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const user = await signInWithGoogle();
      if (user) {
        // Check if profile exists, if not create one
        const profile = await userService.getUserProfile(user.uid);
        if (!profile) {
          await userService.createUserProfile({
            id: user.uid,
            name: user.displayName || 'Anonymous',
            email: user.email || '',
            role: 'citizen',
            avatar: user.photoURL || undefined
          });
        }
        navigate('/dashboard');
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user') {
        setLoading(false);
        return;
      }
      setError(err.message || 'Failed to sign in with Google');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/dashboard');
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        setError('Email/Password login is not enabled in Firebase. Please enable it in the console or use Google Sign-In.');
      } else {
        setError('Invalid email or password. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-6 bg-surface">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <div className="bg-white border border-outline-variant/50 rounded-3xl p-10 shadow-xl relative overflow-hidden group">
          <div className="mb-10 text-center">
             <div className="w-16 h-16 rounded-2xl bg-primary mx-auto mb-6 flex items-center justify-center text-white shadow-lg rotate-3 group-hover:rotate-0 transition-transform">
               <Lock className="w-8 h-8" />
             </div>
             <h1 className="text-3xl font-extrabold tracking-tight mb-2 font-display">Sign In</h1>
             <p className="text-on-surface-variant font-medium text-sm text-balance px-4">Log in as a citizen or administrator to manage municipal reports.</p>
             {error && (
               <div className="mt-4 p-3 bg-error/10 border border-error/20 rounded-xl text-error text-xs font-bold animate-shake">
                 {error}
               </div>
             )}
          </div>

          <form className="space-y-6" onSubmit={handleEmailLogin}>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary group-focus-within:opacity-100 transition-all" />
                <input 
                  type="email" 
                  name="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 h-14 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none transition-all font-bold text-sm"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center ml-2">
                <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block">Password</label>
                <Link to="/forgot-password" size="sm" className="text-[10px] font-black text-on-tertiary-container uppercase tracking-widest hover:underline">Forgot?</Link>
              </div>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary group-focus-within:opacity-100 transition-all" />
                <input 
                  type="password" 
                  name="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 h-14 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none transition-all font-bold text-sm"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full h-14 bg-primary text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-xl mt-4 disabled:opacity-50"
            >
              {loading ? 'Wait...' : 'Sign Into Account'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-10 mb-8 flex items-center gap-4">
            <div className="h-px flex-1 bg-surface-container-high"></div>
            <span className="text-[10px] font-black text-on-surface-variant/40 uppercase tracking-widest">Or continue with</span>
            <div className="h-px flex-1 bg-surface-container-high"></div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              type="button"
              onClick={handleGoogleLogin}
              disabled={loading}
              className="h-14 bg-white border border-outline-variant/30 rounded-2xl flex items-center justify-center gap-3 hover:bg-surface-container-low transition-colors shadow-sm font-bold text-sm disabled:opacity-50"
            >
              <Chrome className="w-5 h-5 text-on-surface-variant" />
              {loading ? 'Wait...' : 'Google'}
            </button>
            <button className="h-14 bg-white border border-outline-variant/30 rounded-2xl flex items-center justify-center gap-3 hover:bg-surface-container-low transition-colors shadow-sm font-bold text-sm">
              <Github className="w-5 h-5 text-on-surface-variant" />
              ID.Gov
            </button>
          </div>

          <p className="text-center text-xs font-bold text-on-surface-variant mt-10">
            Don't have an account? <Link to="/signup" className="text-on-tertiary-container hover:underline">Register today</Link>
          </p>

          <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-primary/5 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-1000"></div>
        </div>
      </motion.div>
    </div>
  );
}
