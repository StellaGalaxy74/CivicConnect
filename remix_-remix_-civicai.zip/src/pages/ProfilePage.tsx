import { motion } from 'motion/react';
import { User, LogOut, Bell, Smartphone, Mail, Globe, MapPin, Camera, ChevronRight, Settings } from 'lucide-react';
import { useApp } from '../App';
import { useNavigate } from 'react-router-dom';

export default function ProfilePage() {
  const { user, signOut } = useApp();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  if (!user) return null;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 md:py-12">
      <header className="mb-10">
        <h1 className="text-3xl font-extrabold tracking-tight mb-2">Profile Settings</h1>
        <p className="text-on-surface-variant font-medium">Manage your citizen identity and application preferences.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Personal Info */}
        <section className="lg:col-span-8 bg-white border border-outline-variant/50 rounded-2xl shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-surface-container flex items-center justify-between">
            <h2 className="text-lg font-bold flex items-center gap-2 text-primary">
               <User className="w-5 h-5" /> Personal Information
            </h2>
          </div>
          
          <div className="p-8">
            <div className="flex flex-col md:flex-row gap-10 items-start">
              <div className="relative group">
                <div className="w-36 h-36 rounded-2xl overflow-hidden border-4 border-surface-container-high shadow-xl rotate-3 group-hover:rotate-0 transition-transform duration-500">
                  <img 
                    src={user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random`} 
                    alt={user.name} 
                    className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-500" 
                  />
                </div>
              </div>

              <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-y-8 gap-x-12 w-full">
                {[
                  { label: 'Full Name', value: user.name },
                  { label: 'Email Address', value: user.email },
                  { label: 'Age', value: user.age?.toString() || 'Not specified' },
                  { label: 'Gender', value: user.gender || 'Not specified' },
                  { label: 'Residential Area', value: 'Downtown District, Sector 7' },
                ].map((field) => (
                  <div key={field.label} className="space-y-1 group">
                    <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block">{field.label}</label>
                    <div className="font-display font-bold text-on-surface text-lg py-2 border-b border-surface-container group-hover:border-primary/30 transition-colors">
                      {field.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Sidebar Settings */}
        <aside className="lg:col-span-4 space-y-8">
          {/* Preferences */}
          <div className="bg-white border border-outline-variant/30 rounded-2xl shadow-sm p-6">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Globe className="w-5 h-5 text-secondary" /> Preferences
            </h3>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block">Primary Language</label>
                <select className="w-full h-11 bg-surface-container-low/50 border border-outline-variant/30 rounded-xl px-4 text-sm font-bold focus:ring-2 focus:ring-secondary/20 focus:border-secondary outline-none transition-all">
                  <option>English (US)</option>
                  <option>Spanish</option>
                  <option>French</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block">Time Zone</label>
                <p className="text-sm font-bold text-on-surface-variant italic">Automated: UTC-5 (Eastern Time)</p>
              </div>
            </div>
          </div>

          {/* Session */}
          <div className="bg-error-container/30 border border-error-container/50 rounded-2xl p-6 relative overflow-hidden group">
            <h3 className="text-lg font-bold text-on-error-container mb-2 relative z-10 flex items-center gap-2">
              <LogOut className="w-5 h-5" /> Session
            </h3>
            <p className="text-xs font-medium text-on-error-container/80 mb-6 relative z-10">Securely sign out of your civic portal session.</p>
            <button 
              onClick={handleLogout}
              className="w-full py-4 bg-white border border-error-container/50 text-error font-black text-xs uppercase tracking-widest rounded-xl hover:bg-error-container/10 transition-all active:scale-[0.98] shadow-sm relative z-10"
            >
              Log Out
            </button>
            <div className="absolute -bottom-8 -right-8 w-24 h-24 bg-error/5 rounded-full blur-2xl group-hover:scale-150 transition-transform"></div>
          </div>
        </aside>

        {/* Notifications Section */}
        <section className="lg:col-span-12 bg-white border border-outline-variant/50 rounded-2xl shadow-sm p-8">
          <div className="flex items-start gap-4 mb-10">
            <div className="p-4 bg-surface-container rounded-2xl text-on-tertiary-container shadow-inner">
               <Bell className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-2xl font-bold tracking-tight">Notification Channels</h3>
              <p className="text-on-surface-variant font-medium">Stay informed about local governance and community alerts.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              { title: 'Push Notifications', desc: 'Real-time alerts for urgent community updates.', icon: Smartphone },
              { title: 'Email Reports', desc: 'Weekly summaries of district progress and meetings.', icon: Mail },
            ].map((item, idx) => (
              <div key={item.title} className="flex items-center justify-between p-8 bg-surface-container-low/50 rounded-2xl border border-outline-variant/10 hover:border-outline-variant transition-all">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white border border-outline-variant/30 flex items-center justify-center text-on-surface-variant/40">
                    <item.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-lg leading-none mb-1">{item.title}</p>
                    <p className="text-sm font-medium text-on-surface-variant/70">{item.desc}</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked={idx === 0} />
                  <div className="w-14 h-7 bg-surface-dim peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-surface-variant after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-secondary"></div>
                </label>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
