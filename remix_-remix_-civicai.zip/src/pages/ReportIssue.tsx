import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Trash2, 
  Map as MapIcon, 
  Mic, 
  Camera, 
  Navigation, 
  Send, 
  ArrowLeft,
  X
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useApp } from '../App';
import { issueService } from '../services/issueService';
import DateTimePicker from '../components/DateTimePicker';
import VoiceInput from '../components/VoiceInput';
import CameraCapture from '../components/CameraCapture';
import { CategoryGrid, CATEGORIES, CategoryID } from '../components/CategorySelection';

import CivicChatbot from '../components/CivicChatbot';

export default function ReportIssuePage() {
  const navigate = useNavigate();

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 md:py-12 min-h-[calc(100vh-140px)]">
      <header className="mb-6 flex items-start gap-4">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-surface-container rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight mb-2">CivicAI Assistant</h1>
          <p className="text-on-surface-variant font-medium">Talk to our AI to report your issue. Our system will automatically analyze, prioritize, and route the complaint to the right department.</p>
        </div>
      </header>

      <CivicChatbot />
      
      <div className="mt-8 text-center">
        <p className="text-xs text-on-surface-variant font-bold opacity-60 uppercase tracking-widest">
          All complaints are automatically verified and routed using Gemini AI.
        </p>
      </div>
    </div>
  );
}


