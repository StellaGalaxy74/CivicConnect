import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { User as UserIcon, Mail, Lock, ArrowRight, ShieldCheck, Chrome, Briefcase, Contact, Calendar, Users2 } from 'lucide-react';
import React, { useState } from 'react';
import { signInWithGoogle, auth } from '../lib/firebase';
import { userService } from '../services/userService';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { cn } from '../lib/utils';

export default function SignupPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [role, setRole] = useState<'citizen' | 'admin'>('citizen');

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    age: '',
    gender: '',
    department: '',
    jobId: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleGoogleSignup = async () => {
    setLoading(true);
    setError(null);
    try {
      const user = await signInWithGoogle();
      if (user) {
        const profile = await userService.getUserProfile(user.uid);
        if (!profile) {
          // If first time Google login, we'll need to collect more info later or use defaults
          // For now, we'll create a basic profile
          await userService.createUserProfile({
            id: user.uid,
            name: user.displayName || 'Anonymous',
            email: user.email || '',
            role: 'citizen',
            avatar: user.photoURL || undefined
          });
        }
        navigate('/dashboard');
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user') {
        setLoading(false);
        return;
      }
      setError(err.message || 'Failed to sign up with Google');
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const user = userCredential.user;

      await updateProfile(user, { displayName: formData.name });

      const profileData: any = {
        id: user.uid,
        name: formData.name,
        email: formData.email,
        role: role,
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(formData.name)}&background=random`,
      };

      if (role === 'citizen') {
        profileData.age = parseInt(formData.age);
        profileData.gender = formData.gender;
      } else {
        profileData.department = formData.department;
        profileData.jobId = formData.jobId;
      }

      await userService.createUserProfile(profileData);
      navigate('/dashboard');
    } catch (err: any) {
      let msg = err.message;
      if (err.code === 'auth/operation-not-allowed') {
        msg = 'Email/Password registration is not enabled in Firebase. Please enable it in the console or join with Google.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please log in instead.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'Please enter a valid email address.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-6 bg-surface py-12">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl w-full"
      >
        <div className="bg-white border border-outline-variant/50 rounded-3xl p-8 md:p-10 shadow-xl relative overflow-hidden group">
          <div className="mb-8">
             <h1 className="text-3xl font-extrabold tracking-tight mb-2 font-display">Create Community Profile</h1>
             <p className="text-on-surface-variant font-medium text-sm">Join our platform to participate in city management.</p>
             {error && (
               <div className="mt-4 p-3 bg-error/10 border border-error/20 rounded-xl text-error text-xs font-bold animate-shake">
                 {error}
               </div>
             )}
          </div>

          <div className="mb-8">
            <div className="flex p-1 bg-surface-container rounded-2xl border border-outline-variant/30 mb-6">
              <button 
                onClick={() => setRole('citizen')}
                className={cn(
                  "flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all gap-2 flex items-center justify-center",
                  role === 'citizen' ? "bg-white shadow-md text-primary" : "text-on-surface-variant/60"
                )}
              >
                <Users2 className="w-4 h-4" />
                Citizen Account
              </button>
              <button 
                onClick={() => setRole('admin')}
                className={cn(
                  "flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all gap-2 flex items-center justify-center",
                  role === 'admin' ? "bg-white shadow-md text-secondary text-primary" : "text-on-surface-variant/60"
                )}
              >
                <ShieldCheck className="w-4 h-4" />
                Municipal Admin
              </button>
            </div>

            <button 
              type="button"
              onClick={handleGoogleSignup}
              disabled={loading}
              className="w-full h-12 bg-white border border-outline-variant/30 rounded-2xl flex items-center justify-center gap-3 hover:bg-surface-container-low transition-colors shadow-sm font-bold text-sm disabled:opacity-50"
            >
              <Chrome className="w-5 h-5 text-on-surface-variant" />
              {loading ? 'Wait...' : 'Join with Google'}
            </button>
            <div className="mt-6 flex items-center gap-4">
              <div className="h-px flex-1 bg-surface-container-high"></div>
              <span className="text-[10px] font-black text-on-surface-variant/40 uppercase tracking-widest">Or enter details</span>
              <div className="h-px flex-1 bg-surface-container-high"></div>
            </div>
          </div>

          <form className="grid grid-cols-1 md:grid-cols-2 gap-5" onSubmit={handleSignup}>
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Full Name</label>
              <div className="relative group">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                <input 
                  type="text" 
                  name="name"
                  required
                  placeholder="e.g. John Doe"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                />
              </div>
            </div>

            <div className="space-y-1.5 md:col-span-2">
              <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Email Address</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                <input 
                  type="email" 
                  name="email"
                  required
                  placeholder="name@example.com"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                />
              </div>
            </div>

            <AnimatePresence mode="wait">
              {role === 'citizen' ? (
                <motion.div 
                  key="citizen-fields"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-5"
                >
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Age</label>
                    <div className="relative group">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                      <input 
                        type="number" 
                        name="age"
                        required
                        placeholder="Age"
                        value={formData.age}
                        onChange={handleInputChange}
                        className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Gender</label>
                    <div className="relative group">
                      <select 
                        name="gender"
                        required
                        value={formData.gender}
                        onChange={handleInputChange}
                        className="w-full px-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm appearance-none"
                      >
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="admin-fields"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-5"
                >
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Department</label>
                    <div className="relative group">
                      <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                      <input 
                        type="text" 
                        name="department"
                        required
                        placeholder="e.g. Roads"
                        value={formData.department}
                        onChange={handleInputChange}
                        className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Job ID</label>
                    <div className="relative group">
                      <Contact className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                      <input 
                        type="text" 
                        name="jobId"
                        required
                        placeholder="e.g. OPS-122"
                        value={formData.jobId}
                        onChange={handleInputChange}
                        className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Password</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                <input 
                  type="password" 
                  name="password"
                  required
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-on-surface-variant/60 uppercase tracking-widest block ml-2">Confirm</label>
              <div className="relative group">
                <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant opacity-40 group-focus-within:text-primary transition-all" />
                <input 
                  type="password" 
                  name="confirmPassword"
                  required
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  className="w-full pl-12 pr-4 h-12 bg-surface-container-low border border-outline-variant/30 rounded-2xl focus:ring-2 focus:ring-primary/10 transition-all font-bold text-sm"
                />
              </div>
            </div>

            <div className="md:col-span-2 mt-4">
              <button 
                type="submit"
                disabled={loading}
                className="w-full h-14 bg-primary text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-xl disabled:opacity-50"
              >
                {loading ? 'Processing...' : 'Create Account'}
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-xs font-bold text-on-surface-variant mt-6">
                Already registered? <Link to="/login" className="text-on-tertiary-container hover:underline">Log in here</Link>
              </p>
            </div>
          </form>

          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000"></div>
        </div>
      </motion.div>
    </div>
  );
}
