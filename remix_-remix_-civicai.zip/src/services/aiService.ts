import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface AIAnalysisResult {
  category: string;
  subcategory: string;
  priority: 'low' | 'medium' | 'high';
  keywords: string[];
  reason: string;
}

export const aiService = {
  async analyzeComplaint(complaint: string): Promise<AIAnalysisResult> {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("Gemini API key is not configured.");
    }

    const prompt = `
      Analyze this civic complaint and return JSON with:
      category, subcategory, priority, keywords, reason.
      
      Rules:
      Road -> pothole, road damage
      Electricity -> streetlight, power
      Water -> leakage, supply
      Garbage -> waste, dustbin
      
      Priority:
      HIGH -> danger, school, hospital
      MEDIUM -> inconvenience
      LOW -> minor issue

      Complaint: "${complaint}"

      Respond ONLY with a valid JSON object.
    `;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });
      
      const text = response.text || "";
      // Remove potential markdown formatting
      const cleanJson = text.replace(/```json/g, "").replace(/```/g, "").trim();
      return JSON.parse(cleanJson);
    } catch (error) {
      console.error("AI Analysis failed:", error);
      // Fallback
      return {
        category: "other",
        subcategory: "general",
        priority: "medium",
        keywords: [],
        reason: "Automatic analysis unavailable."
      };
    }
  }
};
