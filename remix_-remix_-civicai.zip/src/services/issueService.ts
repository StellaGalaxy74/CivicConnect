import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  serverTimestamp,
  Timestamp,
  onSnapshot,
  writeBatch
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Issue, IssueStatus, TimelineEvent, IssuePriority } from '../types';

const ISSUE_COLLECTION = 'issues';
const UPDATE_COLLECTION = 'complaint_updates';

export const issueService = {
  async createIssue(issueData: Omit<Issue, 'id' | 'timestamp' | 'status' | 'priority'>) {
    try {
      const docRef = await addDoc(collection(db, ISSUE_COLLECTION), {
        ...issueData,
        status: 'SUBMITTED',
        priority: 'medium',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        // Ensure images and audioUrl are included if they exist
        images: issueData.images || [],
        audioUrl: issueData.audioUrl || null,
        occurrenceDate: issueData.occurrenceDate || null,
        occurrenceTime: issueData.occurrenceTime || null,
      });

      // Log initial submission
      await addDoc(collection(db, UPDATE_COLLECTION), {
        issueId: docRef.id,
        status: 'SUBMITTED',
        message: 'Complaint submitted by citizen',
        updatedBy: issueData.authorId,
        updatedByName: issueData.authorName,
        timestamp: serverTimestamp()
      });

      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, ISSUE_COLLECTION);
    }
  },

  async updatePriority(id: string, priority: IssuePriority, adminId: string, adminName: string) {
    const issueRef = doc(db, ISSUE_COLLECTION, id);
    const updateRef = collection(db, UPDATE_COLLECTION);
    
    try {
      const batch = writeBatch(db);
      
      batch.update(issueRef, {
        priority,
        updatedAt: serverTimestamp()
      });
      
      batch.set(doc(updateRef), {
        issueId: id,
        status: 'REVIEWED', // Transition to reviewed if prioritized
        message: `Priority updated to ${priority.toUpperCase()}`,
        updatedBy: adminId,
        updatedByName: adminName,
        timestamp: serverTimestamp()
      });
      
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${ISSUE_COLLECTION}/${id}`);
    }
  },

  async updateIssueStatus(id: string, status: IssueStatus, message: string, adminId: string, adminName: string) {
    const issueRef = doc(db, ISSUE_COLLECTION, id);
    const updateRef = collection(db, UPDATE_COLLECTION);
    
    try {
      const batch = writeBatch(db);
      
      batch.update(issueRef, {
        status,
        updatedAt: serverTimestamp()
      });
      
      batch.set(doc(updateRef), {
        issueId: id,
        status,
        message,
        updatedBy: adminId,
        updatedByName: adminName,
        timestamp: serverTimestamp()
      });
      
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${ISSUE_COLLECTION}/${id}`);
    }
  },

  async dispatchTeam(id: string, team: string, adminId: string, adminName: string) {
    const issueRef = doc(db, ISSUE_COLLECTION, id);
    const updateRef = collection(db, UPDATE_COLLECTION);
    
    try {
      const batch = writeBatch(db);
      
      batch.update(issueRef, {
        status: 'ASSIGNED',
        assignedTeam: team,
        updatedAt: serverTimestamp()
      });
      
      batch.set(doc(updateRef), {
        issueId: id,
        status: 'ASSIGNED',
        message: `Team dispatched: ${team}`,
        updatedBy: adminId,
        updatedByName: adminName,
        timestamp: serverTimestamp()
      });
      
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${ISSUE_COLLECTION}/${id}`);
    }
  },

  async resolveIssue(id: string, adminId: string, adminName: string) {
    return this.updateIssueStatus(id, 'RESOLVED', 'Issue resolved by administration.', adminId, adminName);
  },

  async updateIssue(id: string, updates: Partial<Issue>) {
    const docRef = doc(db, ISSUE_COLLECTION, id);
    try {
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${ISSUE_COLLECTION}/${id}`);
    }
  },

  async getIssue(id: string) {
    const docRef = doc(db, ISSUE_COLLECTION, id);
    try {
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          timestamp: data.createdAt ? (data.createdAt as Timestamp).toDate().toLocaleDateString() : 'Just now'
        } as Issue;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `${ISSUE_COLLECTION}/${id}`);
    }
  },

  subscribeToIssues(onUpdate: (issues: Issue[]) => void) {
    const q = query(collection(db, ISSUE_COLLECTION), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const issues = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          timestamp: data.createdAt ? (data.createdAt as Timestamp).toDate().toLocaleDateString() : 'Just now'
        } as Issue;
      });
      onUpdate(issues);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, ISSUE_COLLECTION);
    });
  },

  subscribeToUserIssues(userId: string, onUpdate: (issues: Issue[]) => void) {
    const q = query(
      collection(db, ISSUE_COLLECTION), 
      where('authorId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    return onSnapshot(q, (snapshot) => {
      const issues = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          timestamp: data.createdAt ? (data.createdAt as Timestamp).toDate().toLocaleDateString() : 'Just now'
        } as Issue;
      });
      onUpdate(issues);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, ISSUE_COLLECTION);
    });
  },

  subscribeToTimeline(issueId: string, onUpdate: (events: TimelineEvent[]) => void) {
    const q = query(
      collection(db, UPDATE_COLLECTION),
      where('issueId', '==', issueId),
      orderBy('timestamp', 'asc')
    );
    return onSnapshot(q, (snapshot) => {
      const events = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          issueId: data.issueId,
          status: data.status,
          message: data.message,
          updatedBy: data.updatedBy,
          updatedByName: data.updatedByName,
          timestamp: data.timestamp
        } as TimelineEvent;
      });
      onUpdate(events);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, UPDATE_COLLECTION);
    });
  }
};
