import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc,
  serverTimestamp
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { User } from '../types';

const USER_COLLECTION = 'users';

export const userService = {
  async getUserProfile(userId: string) {
    const docRef = doc(db, USER_COLLECTION, userId);
    try {
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data
        } as User;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `${USER_COLLECTION}/${userId}`);
    }
  },

  async createUserProfile(user: User) {
    const docRef = doc(db, USER_COLLECTION, user.id);
    try {
      await setDoc(docRef, {
        ...user,
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${USER_COLLECTION}/${user.id}`);
    }
  },

  async updateUserProfile(userId: string, updates: Partial<User>) {
    const docRef = doc(db, USER_COLLECTION, userId);
    try {
      await updateDoc(docRef, updates);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${USER_COLLECTION}/${userId}`);
    }
  }
};
