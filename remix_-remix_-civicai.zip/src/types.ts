export type Role = 'citizen' | 'admin' | null;
export type IssueStatus = 'SUBMITTED' | 'REVIEWED' | 'ASSIGNED' | 'IN_PROGRESS' | 'RESOLVED';
export type IssuePriority = 'low' | 'medium' | 'high' | 'urgent';

export interface TimelineEvent {
  id: string;
  issueId: string;
  status: IssueStatus;
  message: string;
  updatedBy: string;
  updatedByName: string;
  timestamp: any;
}

export interface Issue {
  id: string;
  title: string;
  summary: string;
  category: 
    | 'water' 
    | 'roads' 
    | 'sanitation' 
    | 'electricity' 
    | 'safety' 
    | 'traffic' 
    | 'parks' 
    | 'health' 
    | 'infrastructure' 
    | 'animals' 
    | 'lights' 
    | 'transport' 
    | 'drainage' 
    | 'noise' 
    | 'construction' 
    | 'other';
  status: IssueStatus;
  priority: IssuePriority;
  location: string;
  latitude?: number;
  longitude?: number;
  timestamp: string;
  occurrenceDate?: string;
  occurrenceTime?: string;
  authorId: string;
  authorName: string;
  image?: string;
  images?: string[];
  audioUrl?: string;
  assignedTeam?: string;
  assignedOfficer?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar?: string;
  age?: number;
  gender?: string;
  department?: string;
  jobId?: string;
  createdAt?: any;
}
